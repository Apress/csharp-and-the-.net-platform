using System;
using System.Collections;

namespace Boxing
{
	class Boxer
	{
		#region Helper f(x)'s
		// Helper f(x) to illustrate automatic boxing.
		public static void Foo(object o)
		{
			Console.WriteLine(o.GetType());
			Console.WriteLine(o.ToString());
			Console.WriteLine("Value of o is: {0}", o);

			// Need to unbox to get at members of
			// System.Int32.
			int unboxedInt = (int)o;
			Console.WriteLine(unboxedInt.GetTypeCode());
		}

		public static void BoxAndUnboxInts()
		{
			// Box ints into ArrayList.
			ArrayList myInts = new ArrayList();
			myInts.Add(88);
			myInts.Add(3);
			myInts.Add(9764);

			// Unbox first item.
			int firstItem = (int)myInts[0];

			// Another boxing operation!
			Console.WriteLine("First item is {0}", firstItem);
		}
		#endregion

		static void Main(string[] args)
		{		
			// Make a simple value type.
			Console.WriteLine("***** Boxing short *****");
			short s = 25;
			Console.WriteLine("short s = {0}", s);
			Console.WriteLine("short is a: {0}", s.GetType().ToString());

			// Box the value type into a reference type.
			object objShort = s;
			Console.WriteLine("Boxed object is a: {0}", objShort.GetType().ToString());
		
			// Now, unbox the reference back into a short:
			Console.WriteLine("\n***** Unboxing short *****");
			short anotherShort = (short)objShort;
			Console.WriteLine("short anotherShort = {0}", anotherShort);
			Console.WriteLine("Unboxed object is a: {0}", anotherShort.GetType().ToString());

			// Bad unboxing!
			Console.WriteLine("\n***** Unboxing short into string! *****");
			try
			{
				// The type contained in the box is NOT a
				// string, but a short!
				string str = (string)objShort;
			}
			catch(InvalidCastException e)
			{
				Console.WriteLine("OOPS!\n{0}", e.ToString());
			}

			// Auto-box.
			Console.WriteLine("\n***** Calling Foo() *****");
			int x = 99;
			Foo(x);

			Console.WriteLine("\n***** Calling BoxAndUnboxInts() *****");
			BoxAndUnboxInts();			
		}
	}
}
