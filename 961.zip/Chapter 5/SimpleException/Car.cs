using System;

namespace SimpleException
{
	public class Car 
	{
		// Internal state data.
		private int currSpeed;
		private int maxSpeed;
		private string petName;

		// Is the car alive or dead?
		bool carIsDead;

		#region ctors
		// A car has-a radio.
		private Radio theMusicBox = new Radio();

		public Car()
		{
			maxSpeed = 100;
			carIsDead = false;
		}

		public Car(string name, int max, int curr)
		{
			currSpeed = curr;
			maxSpeed = max;
			petName = name;
			carIsDead = false;
		}
		#endregion 

		public void CrankTunes(bool state)
		{
			// Tell the radio play (or not).
			// Delegate request to inner object.
			theMusicBox.TurnOn(state);
		}

		public void SpeedUp(int delta) 
		{
			// If the car is dead, throw exception...
			if(carIsDead)
			{
				Exception ex = new Exception("Error information can be found at:");
				ex.HelpLink = "http://www.intertech-inc.com";
				throw ex;
			}
			else	// Not dead, so speed up.
			{
				currSpeed += delta;
				if(currSpeed >= maxSpeed)
				{
					carIsDead = true;
				}
				else
					Console.WriteLine("=> CurrSpeed = {0}", currSpeed);
			}
		}
	}
}

