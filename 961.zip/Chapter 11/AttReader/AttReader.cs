using System;
using CustomAtt;

namespace AttReader
{
	public class AttReader
	{
		public static int Main(string[] args)
		{
			// Get the Type of winnebago.
			Type t = typeof(Winnebago);
		
			// Get all attributes in the assembly.
			object[] customAtts = t.GetCustomAttributes(false);
		
			// List all info.
			Console.WriteLine("***** Value of VehicleDescriptionAttribute *****\n");
			foreach(VehicleDescriptionAttribute v in customAtts)
				Console.WriteLine("-> {0}\n", v.Desc);	

			return 0;
		}
	}
}
