Imports AirVehicles
Imports System.Windows.Forms

Module Module1
    Sub Main()
        UseHelicopter()
        MessageBox.Show("Click to load ufo.netmodule")
        UseUFO()
        MessageBox.Show("Done")
    End Sub

    Sub UseHelicopter()
        Dim h As New AirVehicles.Helicopter()
        h.TakeOff()
    End Sub
    Sub UseUFO()
        ' This will load the *.netmodule on demand.
        Dim u As New UFO()
        u.AbductHuman()
    End Sub
End Module
