using System;

namespace Nested
{
	// C# allows nesting of classes, interfaces and structures.
	// Here, the car nests the radio.
	public class Car  
	{
		// Internal state data.
		private int currSpeed;
		private int maxSpeed;
		private string petName;

		// Is the car alive or dead?
		bool carIsDead;
		
		#region Nested radio
		// A nested, private radio.
		private class Radio
		{
			public void TurnOn(bool on)
			{
				if(on)
					Console.WriteLine("Jamming...");
				else
					Console.WriteLine("Quiet time...");
			}
		}
		#endregion 

		// A car has-a radio.
		private Radio theMusicBox = new Radio();

		#region Constructors
		public Car()
		{
			maxSpeed = 100;
			carIsDead = false;
		}

		public Car(string name, int max, int curr)
		{
			currSpeed = curr;
			maxSpeed = max;
			petName = name;
			carIsDead = false;
		}
		#endregion 

		public void CrankTunes(bool state)
		{
			// Tell the radio play (or not).
			// Delegate request to inner object.
			theMusicBox.TurnOn(state);
		}

		public void SpeedUp(int delta)
		{
			// If the car is dead, just say so...
			if(carIsDead)
			{
				Console.WriteLine("{0} is out of order....", petName);
			}
			else	// Not dead, speed up.
			{
				currSpeed += delta;
				if(currSpeed >= maxSpeed)
				{
					Console.WriteLine("Sorry, {0} has overheated...", petName );
					carIsDead = true;
				}
				else
					Console.WriteLine("=> CurrSpeed = {0}", currSpeed);
			}
		}
	}
}

