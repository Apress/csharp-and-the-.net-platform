using System;
using System.Collections;

namespace IndexerCodeLibrary
{
	public class Cars : IEnumerable
	{
		// This class maintains an array of cars.
		private ArrayList carArray;
	
		public Cars()
		{
			carArray = new ArrayList();
		}

		// The indexer.
		public Car this[int pos]
		{
			get
			{
				if(pos < 0)
					throw new IndexOutOfRangeException("Hey! Index out of range");
				else
					return (Car)carArray[pos];
			}
			set
			{
				carArray.Insert(pos, value);
			}
		}
	
		public int GetNumberOfCars()
		{
			return carArray.Count;
		}

		// This must be present in order to let the foreach 
		// expression to iterate over our array.
		// IEnumerable implemtation.
		public IEnumerator GetEnumerator()
		{
			return carArray.GetEnumerator();
		}
	}
}
