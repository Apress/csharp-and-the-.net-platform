using System;

/* Note!  I have set some command line
 * parameters using the Properties 
 * dialog.  So don't be freaked out 
 * if you can't seem to figure out
 * where -Foo, -Bar and -GODMODE 
 * are coming from ;-) */

#region The Hello Class
class HelloClass
{
	// Default constructor has been redefined. 
	public HelloClass()
    {	
		Console.WriteLine("Default ctor called!");
    }
		
	// This custom constructor assigns state data to a known value.
	public HelloClass (int x, int y)
	{
		Console.WriteLine("Custom ctor called!");
		intX = x;
		intY = y;
	}
	
	// Sample state data.
	public int intX, intY;

	// Simple member function.
	public void SayHi() {Console.WriteLine("Hi there!");}
}
#endregion 

#region The Hello App
class HelloApp
{
	// Program entry point.
	public static int Main(string[] args)
	{
		// Uncomment to trigger error.
		// HelloClass c;
		// c.SayHi();    // Error!  

		// Process command line arguments...
		Console.WriteLine("***** Command line args *****");
		for(int x = 0; x < args.Length; x++)
		{
			Console.WriteLine("Arg: {0}", args[x]);
		}

		// One more time using foreach!
		Console.WriteLine("\n***** Just in case you missed *****");
		foreach(string s in args)
			Console.WriteLine("Arg: {0}", s);

		// Now using System.Environment
		Console.WriteLine("\n***** Using System.Environment *****");
		string[] theArgs = Environment.GetCommandLineArgs();
		Console.WriteLine("Path is: {0}", theArgs[0]);

		for(int i =1; i < theArgs.Length; i++)
			Console.WriteLine("Again, the args are {0}", theArgs[i]);
		Console.WriteLine();

		// Make instance of HelloClass. 
		HelloClass c1 = new HelloClass ();
		c1.SayHi();
		Console.WriteLine("c1.intX = {0}\nc1.intY = {1}\n", c1.intX, c1.intY);
		
		// Another instance of HelloClass.
		HelloClass c2;
		c2 = new HelloClass(100, 200);
		c2.SayHi();
		Console.WriteLine("c2.intX = {0}\nc2.intY = {1}\n", c2.intX, c2.intY);
		return 0;
	}
}
#endregion