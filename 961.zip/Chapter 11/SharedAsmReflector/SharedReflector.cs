using System;
using System.Reflection;
using System.IO;

namespace SharedAsmReflector
{
	public class SharedAsmReflector
	{
		private static void DisplayInfo(Assembly a)
		{
			Console.WriteLine("***** Info about Assembly *****");
			Console.WriteLine("Loaded from GAC? {0}", a.GlobalAssemblyCache);
			Console.WriteLine("Asm Name: {0}", a.GetName().Name);
			Console.WriteLine("Asm Version: {0}", a.GetName().Version);
			Console.WriteLine("Asm Culture: {0}", a.GetName().CultureInfo.DisplayName);
			Type[] types = a.GetTypes();
			foreach(Type t in types)
				Console.WriteLine("Type: {0}", t);
			Console.WriteLine("******************************\n");
		}
 
		public static int Main(string[] args)
		{
			Console.WriteLine("***** The Shared Asm Reflector App *****\n");
			// Load SharedAssembly.dll from GAC.
			// ***** NOTE!!!  You will need to supply
			// your publickeytoken!! *****
			Assembly a = null;
			string displayName = "SharedAssembly," +  
							   "Version=1.0.0.0," +  
                               "PublicKeyToken=d4e2ed23cced0257," + 
                               @"Culture=""";
			try
			{
				a = Assembly.Load(displayName);
			}
			catch
			{
				Console.WriteLine("Can't find asm!! Check display name");
				return -1;
			}
			DisplayInfo(a);

			// Load System.Drawing.Design.dll from GAC.
			displayName = null;
			displayName = "System.Drawing.Design," +  
				"Version=1.0.5000.0," +  
				"PublicKeyToken=b03f5f7f11d50a3a," + 
				@"Culture=""";
			a = Assembly.Load(displayName);
			DisplayInfo(a);
			return 0;
		}
	}
}
