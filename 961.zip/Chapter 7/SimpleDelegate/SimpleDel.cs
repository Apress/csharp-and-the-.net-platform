using System;

namespace SimpleDelegate
{
	class DelegateApp
	{
		#region Functions called by delegate...
		// This is the method that will be called
		// by the delegate.
		public static void PlainPrint(string msg)
		{
			Console.WriteLine("Msg is: {0}", msg);
		}

		public static void UpperCasePrint(string msg)
		{
			Console.WriteLine("Msg is: {0}", msg.ToUpper());
		}
		public static void XXXXYYYYZZZZ888777aaa(string msg)
		{
			Console.WriteLine("Msg is: {0}", msg);
		}

		// Bad target!
		public void BadTargetForDelegate(int x, AppDomain y)
		{
			// Stuff.
		}
		#endregion 
    
		// Define a delegate.
		public delegate void AnyMethodTakingAString(string s);

		public static void Main()
		{
			Console.WriteLine("***** A very simple delegate example *****\n");
			// Make the delegate.
			AnyMethodTakingAString del;
			del = new AnyMethodTakingAString(PlainPrint);
			del("Hello there...");
			Console.WriteLine("->I just called: {0}\n", del.Method);

			// Reassign and invoke delegate.
			del= new AnyMethodTakingAString(UpperCasePrint);
			del("Hello there...");
			Console.WriteLine("->I just called: {0}\n", del.Method);

			// Reassign and invoke delegate.
			del= new AnyMethodTakingAString(XXXXYYYYZZZZ888777aaa);
			del("Hello there...");
			Console.WriteLine("->I just called: {0}\n", del.Method);

			// This is not a valid target! Error!
			// del = new AnyMethodTakingAString(BadTargetForDelegate);
			// del("Huh?!?");

			// Now some multicasting.
//			AnyMethodTakingAString myMultiCaster;
//			myMultiCaster = new AnyMethodTakingAString(PlainPrint);
//			myMultiCaster += new AnyMethodTakingAString(UpperCasePrint);
//			myMultiCaster += new AnyMethodTakingAString(XXXXYYYYZZZZ888777aaa);
//			myMultiCaster("Here is a string");

		}
	}
}