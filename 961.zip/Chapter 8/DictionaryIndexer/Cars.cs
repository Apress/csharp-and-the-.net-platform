using System;
using System.Collections;
using System.Collections.Specialized;

namespace DictionaryIndexer
{
	public class Cars
	{
		// This class maintains an dictionary of cars.
		private ListDictionary carDictionary;
		
		public Cars()
		{
			carDictionary = new ListDictionary();
		}

		// The string indexer.
		public Car this[string name]
		{
			get { return (Car)carDictionary[name];}
			set { carDictionary.Add(name, value);}
		}
		
		// The int indexer.
		public Car this[int item]
		{
			get { return (Car)carDictionary[item];}
			set { carDictionary.Add(item, value);}
		}
	}
}
