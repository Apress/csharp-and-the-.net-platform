using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace CalcWebService
{
	[WebService(Description = "The Amazing Calculator Web Service!",
		 Namespace ="http://www.intertech-inc.com/WebServers", 
		 Name = "MyWayCoolWebCalculator")]
	public class CalcWS : System.Web.Services.WebService
	{
		public CalcWS()
		{
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		#region The web methods.
		[WebMethod(Description = "Yet another way to add numbers!")]
		public int Add(int x, int y){  return x + y; }         

		[WebMethod(Description = "Yet another way to subtract numbers!")]
		public int Subtract(int x, int y){  return x - y; } 
		
		[WebMethod(Description = "Yet another way to multiply numbers!")]
		public int Multiply(int x, int y){  return x * y; } 
		
		[WebMethod(Description = "Yet another way to divide numbers!")]
		public int Divide(int x, int y)
		{ 
			// To service all wire protocols, simply return 0 
			// (rather than a .NET exception, which is SOAP specific).
			if(y == 0)
				return 0;  
			else
				return x / y; 
		} 

		[WebMethod(Description = "Add 2 floats.", MessageName = "AddFloats")]
		public float Add(float x, float y){  return x + y; } 

		[WebMethod(Description = "Get app variable")]
		public float GetSimplePI()
		{ return (float)Application["SimplePI"]; } 

		[WebMethod(EnableSession = true, 
			 Description = "Get your random number!")]
		public int GetMyRandomNumber()
		{ return (int)Session["SessionRandomNumber"]; } 

		#endregion
	}
}
