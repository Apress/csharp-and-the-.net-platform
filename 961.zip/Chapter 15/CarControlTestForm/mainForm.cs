using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CarControlTestForm
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class mainForm : System.Windows.Forms.Form
	{
		private CarControlLibrary.CarControl carControl1;
		private System.Windows.Forms.Button btnSlowDown;
		private System.Windows.Forms.Button btnSpeedUp;
		private System.Windows.Forms.Label lblEventMsg;
		private System.Windows.Forms.Label lblCurrSp;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public mainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.carControl1 = new CarControlLibrary.CarControl();
			this.btnSlowDown = new System.Windows.Forms.Button();
			this.btnSpeedUp = new System.Windows.Forms.Button();
			this.lblEventMsg = new System.Windows.Forms.Label();
			this.lblCurrSp = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// carControl1
			// 
			this.carControl1.Location = new System.Drawing.Point(16, 16);
			this.carControl1.Name = "carControl1";
			this.carControl1.PetName = "Bill";
			this.carControl1.Size = new System.Drawing.Size(96, 128);
			this.carControl1.TabIndex = 0;
			this.carControl1.TextPaneColor = System.Drawing.Color.SlateBlue;
			this.carControl1.BlewUp += new CarControlLibrary.CarControl.CarEventHandler(this.carControl1_BlewUp);
			this.carControl1.AboutToBlow += new CarControlLibrary.CarControl.CarEventHandler(this.carControl1_AboutToBlow);
			// 
			// btnSlowDown
			// 
			this.btnSlowDown.Location = new System.Drawing.Point(136, 56);
			this.btnSlowDown.Name = "btnSlowDown";
			this.btnSlowDown.TabIndex = 1;
			this.btnSlowDown.Text = "Slow Down";
			this.btnSlowDown.Click += new System.EventHandler(this.btnSlowDown_Click);
			// 
			// btnSpeedUp
			// 
			this.btnSpeedUp.Location = new System.Drawing.Point(136, 16);
			this.btnSpeedUp.Name = "btnSpeedUp";
			this.btnSpeedUp.TabIndex = 2;
			this.btnSpeedUp.Text = "Speed Up";
			this.btnSpeedUp.Click += new System.EventHandler(this.btnSpeedUp_Click);
			// 
			// lblEventMsg
			// 
			this.lblEventMsg.Location = new System.Drawing.Point(136, 96);
			this.lblEventMsg.Name = "lblEventMsg";
			this.lblEventMsg.TabIndex = 3;
			// 
			// lblCurrSp
			// 
			this.lblCurrSp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblCurrSp.Location = new System.Drawing.Point(16, 168);
			this.lblCurrSp.Name = "lblCurrSp";
			this.lblCurrSp.TabIndex = 4;
			// 
			// mainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(256, 209);
			this.Controls.Add(this.lblCurrSp);
			this.Controls.Add(this.lblEventMsg);
			this.Controls.Add(this.btnSpeedUp);
			this.Controls.Add(this.btnSlowDown);
			this.Controls.Add(this.carControl1);
			this.Name = "mainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CarControl Test Form";
			this.Load += new System.EventHandler(this.mainForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new mainForm());
		}

		private void carControl1_AboutToBlow(string msg)
		{
			lblEventMsg.Text = msg;
		}

		private void carControl1_BlewUp(string msg)
		{
			lblEventMsg.Text = msg;
		}

		private void btnSpeedUp_Click(object sender, System.EventArgs e)
		{
			carControl1.Speed += 10;
			lblCurrSp.Text = 
				string.Format("Speed is: {0}", carControl1.Speed.ToString());
		}

		private void btnSlowDown_Click(object sender, System.EventArgs e)
		{
			carControl1.Speed -= 10;
			lblCurrSp.Text = 
				string.Format("Speed is: {0}", carControl1.Speed.ToString());
		}

		private void mainForm_Load(object sender, System.EventArgs e)
		{
			carControl1.Anim = true;
			lblCurrSp.Text = 
				string.Format("Speed is: {0}", carControl1.Speed.ToString());
		}
	}
}
