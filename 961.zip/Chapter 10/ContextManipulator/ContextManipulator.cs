using System;
using System.Runtime.Remoting.Contexts;
using System.Threading;

namespace ContextManipulator
{
	#region Example class types
	// These classes have no special contextual
	// needs, and will thus be loaded into the 
	// default context of the app domain.
	public class NoSpecialContextClass
	{
		public NoSpecialContextClass()
		{
			Context ctx = Thread.CurrentContext;
			Console.WriteLine("Info about context {0}", 
				ctx.ContextID);

			foreach(IContextProperty itfCtxProp 
						in ctx.ContextProperties)
				Console.WriteLine("-> Ctx Prop: {0}", itfCtxProp.Name);
		}
	}

	public class NoSpecialContextClass2
	{
		public NoSpecialContextClass2()
		{
			Context ctx = Thread.CurrentContext;
			Console.WriteLine("Info about context {0}", ctx.ContextID);
			foreach(IContextProperty itfCtxProp in ctx.ContextProperties)
				Console.WriteLine("-> Ctx Prop: {0}", itfCtxProp.Name);
		}
	}

	// This class demands to be loaded in 
	// a synchronization context.
	[Synchronization]
	public class SynchContextClass : ContextBoundObject
	{
		public SynchContextClass()
		{
			Context ctx = Thread.CurrentContext;
			Console.WriteLine("Info about context {0}", ctx.ContextID);
			foreach(IContextProperty itfCtxProp in ctx.ContextProperties)
				Console.WriteLine("-> Ctx Prop: {0}", itfCtxProp.Name);
		}
	}
	#endregion

	class ContextChecker
	{
		static void Main(string[] args)
		{
			Console.WriteLine("***** The Amazing Context Application *****\n");

			// Make each class type and print contextual info.
			NoSpecialContextClass noBigDealObj = new NoSpecialContextClass();
			Console.WriteLine();

			NoSpecialContextClass2 noBigDealObj2 = new NoSpecialContextClass2();
			Console.WriteLine();

			SynchContextClass synchObj = new SynchContextClass();
			Console.WriteLine();
		}
	}
}
