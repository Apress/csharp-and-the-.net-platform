using System;

namespace Employees
{
	// Employee is the base class in this hierarchy.
	// It serves to hold data & functionality 
	// common to all employee types.
	abstract public class Employee
	{
		// protected data for kids.
		protected  string fullName;
		protected int empID;
		protected float currPay;
		protected string empSSN;	
	
		// private static data.
		private static string companyName;

		// Readonly field (just for example purposes).
		public readonly string SSNField;

		#region Constructors
		// Default ctor.
		public Employee(){}

		// Custom ctor
		public Employee(string FullName, int empID, 
			float currPay, string ssn)
		{
			// Assign internal state data.
			// Note use of 'this' keyword
			// to avoid name clashes.
			this.fullName = FullName;
			this.empID = empID;
			this.currPay = currPay;
			this.empSSN = ssn;
			
			// Assign read only field.
			SSNField = ssn;
		}

		// A static ctor (to assign static field)
		static Employee()
		{companyName = "Intertech, Inc";}

		// If the user calls this ctor, forward to the 4-arg version
		// using arbitrary values...
		public Employee(string fullName) 
			: this(fullName, 3333, 0.0F, ""){}
		#endregion 

		#region Methods
		// Bump the pay for this emp.
		public virtual void GiveBonus(float amount)
		{currPay += amount;}

		// Show state (could use ToString() as well)
		public virtual void DisplayStats()
		{
			Console.WriteLine("Name: {0}", fullName);
			Console.WriteLine("Pay: {0}", currPay);
			Console.WriteLine("ID: {0}", empID);
			Console.WriteLine("SSN: {0}", empSSN);
		}

		// Accessor & mutator for the FirstName.
		public string GetFullName() { return fullName; } 
		public void SetFullName(string n) 
		{ 
			// Remove any illegal characters (!,@,#,$,%),
			// check maximum length or case before making assignment.
			fullName = n; 
		}
		#endregion 

		#region properties
		// A static property.
		public static string Company
		{
			get { return companyName; }
			set { companyName = value;}
		}

		// Property for the empID.
		public int EmpID 
		{
			get {return empID;}
			set 
			{
				#if DEBUG
					Console.WriteLine("value is an instance of: {0} ", value.GetType()); 
					Console.WriteLine("value as string: {0} ", value.ToString());
				#endif
				empID = value;
			}
		}
		
		// Property for the currPay.
		public float Pay 
		{
			get {return currPay;}
			set {currPay = value;}
		}

		// Another property for ssn.
		public string SSN
		{
			get { return empSSN; }
		}
		#endregion 
	}
}
