using System;
using System.Data;

namespace DataRowState
{
    public class DRState
    {
		public static void Main()
		{	
			Console.WriteLine("***** The RowState property *****");

			// Build a single column DataTable
			DataTable myTable = new DataTable("Employees");
			DataColumn colID = new DataColumn("empID", 
										 Type.GetType("System.Int32"));
			myTable.Columns.Add(colID);

			// The DataRow.
			DataRow myRow;
			
			// Create a new (detached) DataRow.
			Console.WriteLine("Made new DataRow");
			myRow = myTable.NewRow();
			Console.WriteLine("->Row state: {0}\n", myRow.RowState.ToString());

			// Now add it to table.
			Console.WriteLine("Added DataRow to DataTable");
			myTable.Rows.Add(myRow);
			Console.WriteLine("->Row state: {0}\n", myRow.RowState.ToString());

			// Trigger an accept.
			Console.WriteLine("Called AcceptChanges() on DataTable");
			myTable.AcceptChanges();
			Console.WriteLine("->Row state: {0}\n", myRow.RowState.ToString());

			// Modify it.
			Console.WriteLine("Modified DataRow");
			myRow["empID"] = 100;
			Console.WriteLine("->Row state: {0}\n", myRow.RowState.ToString());

			// Now delete it.
			Console.WriteLine("Deleted DataRow");
			myRow.Delete();
			Console.WriteLine("->Row state: {0}\n", myRow.RowState.ToString());
			myRow.AcceptChanges();	
		}
	}
}
