using System;
using System.Data;
using System.Data.OleDb;

namespace OleDbDataReaderApp
{
	public class OleDbDR
	{
		public static void Main(string[] args)
		{
			OleDbConnection cn = new OleDbConnection();

			// For Access DB manipulation, switch connection
			// string values (adjust path if needed).
			// cn.ConnectionString = @"Provider=Microsoft.JET.OLEDB.4.0;data source = C:\cars.mdb";     

			cn.ConnectionString = "Provider=SQLOLEDB.1;" +
				"User ID=sa;Pwd=;Initial Catalog=Cars;" + 
				"Data Source=(local);Connect Timeout=30";  
       		
			// Open the connection.
			cn.Open();

			#region Connection stats
			Console.WriteLine("***** Info about your connection *****");
			Console.WriteLine("Database location: {0}", cn.DataSource);
			Console.WriteLine("Database name: {0}", cn.Database);
			Console.WriteLine("Provider: {0}", cn.Provider);
			Console.WriteLine("Timeout: {0}", cn.ConnectionTimeout);
			Console.WriteLine("Connection state: {0}", cn.State.ToString());

			// Multiple Close() calls on a closed connection OK!
			cn.Close();
			cn.Close();
			cn.Close();
			cn.Close();
			Console.WriteLine("Connection state: {0}", cn.State.ToString());
			cn.Open();
			Console.WriteLine("Connection state: {0}", cn.State.ToString());
			Console.WriteLine();
			#endregion 

			#region Schema info example
			Console.WriteLine("***** Some schema info about Cars database *****");
			DataTable dtSchemaInfo = cn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
				new object[] {null, null, null, "TABLE"});
			PrintDataTable(dtSchemaInfo);
			#endregion

			#region Data Reader example
			// Create a SQL command.
			string strSQL = "SELECT Make FROM Inventory WHERE Color='Red'"; 
			OleDbCommand myCommand = new OleDbCommand(strSQL, cn);

			// Obtain a data reader ala ExecuteReader().
			OleDbDataReader myDataReader;
			myDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
			
			// Loop over the results.
			Console.WriteLine("\n***** Red cars obtained from a DataReader *****");
			while (myDataReader.Read()) 
			{
				Console.WriteLine("-> Make: {0}", myDataReader["Make"].ToString());
			}    
		
			//cn.Close();
			Console.WriteLine("State of connection is: {0}", cn.State);
			#endregion

			#region Schema info from DataReader example
			Console.WriteLine("\n***** Schema info for table *****");
			DataTable dt = myDataReader.GetSchemaTable();
			PrintDataTable(dt); 
			#endregion

			// Because we specified CommandBehavior.CloseConnection, we 
			// don't need to explicitly call Close() on the connection.
			myDataReader.Close();
		}

		#region Print table helper function
		private static void PrintDataTable(DataTable dt)
		{
			// Print the DataTable.
			for(int curRow = 0; curRow < dt.Rows.Count; curRow++)
			{
				for(int curCol= 0; curCol< dt.Columns.Count; curCol++)					
				{
					Console.Write(dt.Rows[curRow][curCol].ToString().Trim()+ " ");				
				}
				Console.WriteLine();
			}
		}
		#endregion
	}
}
