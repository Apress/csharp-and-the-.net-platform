using System;
using System.Data;
using System.Data.OleDb;

namespace UpdateDBWithCommandObj
{
	class UpdateWithCommandObj
	{
		static void Main(string[] args)
		{
			Console.WriteLine("*************************************************************");
			Console.WriteLine("*** This app inserts, modifies and deletes a new auto *******");
			Console.WriteLine("*** using the connected layer of ADO .NET (OleDbCommand) ****");
			Console.WriteLine("*************************************************************");

			// Open a connection to Cars db.
			OleDbConnection cn = new OleDbConnection();
			cn.ConnectionString = "Provider=SQLOLEDB.1;" +
				"User ID=sa;Pwd=;Initial Catalog=Cars;" + 
				"Data Source=(local);Connect Timeout=30";
			cn.Open();

			string sql = "";
			OleDbCommand cmd = null;

			#region Insert new car
			Console.WriteLine("***** Hit a key to insert new record *****");
			Console.ReadLine();

			// SQL insert.
			sql = "INSERT INTO Inventory" + 
				"(CarID, Make, Color, PetName) VALUES" +
				"('777', 'Honda', 'Silver', 'NoiseMaker')";

			// Create an INSERT command.
			cmd = new OleDbCommand(sql, cn);
			try
			{
				Console.WriteLine("Number of rows effected: {0}", cmd.ExecuteNonQuery()); 
			}
			catch(Exception ex)
			{Console.WriteLine(ex.Message);}
			finally
			{Console.WriteLine("Done!");}
			#endregion

			#region Update car
			Console.WriteLine("Hit a key to update existing record");
			Console.ReadLine();

			sql = "UPDATE Inventory SET Make = 'Hummer' WHERE CarID = '777'";
			cmd.CommandText = sql;
			try
			{
				Console.WriteLine("Number of rows effected: {0}", cmd.ExecuteNonQuery());
			}
			catch(Exception ex)
			{Console.WriteLine(ex.Message);}
			finally
			{Console.WriteLine("Done!");}
			#endregion

			#region Delete car
			Console.WriteLine("Hit a key to delete new record");
			Console.ReadLine();
			sql = "Delete from Inventory where CarID = '777'";
			cmd.CommandText = sql;
			try
			{
				Console.WriteLine("Number of rows effected: {0}", cmd.ExecuteNonQuery());
			}
			catch(Exception ex)
			{Console.WriteLine(ex.Message);}
			finally
			{Console.WriteLine("Done!");}
			#endregion

			cn.Close();
		}
	}
}
