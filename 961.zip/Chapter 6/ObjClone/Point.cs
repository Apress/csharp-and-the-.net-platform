using System;

namespace ObjClone
{
	#region The point description type
	// This class describes a point.
	public class PointDesc
	{
		// Public for easy access.
		public string petName;
		public DateTime creationDate;

		public PointDesc(string petName)
		{
			this.petName = petName;

			// Inject a time lag to get
			// different times.
			System.Threading.Thread.Sleep(2000);
			creationDate = DateTime.Now;
		}

		public string CreationTime() 
		{
			// Return a string with date / time
			// information. 
			return creationDate.ToString();
		}
	}
	#endregion 

	#region Cloneable point type
	// The Point class supports deep copy
	// semantics ala ICloneable.
	public class Point : ICloneable
	{
		// State data.
		public int x, y;
		public PointDesc desc;

		// Ctors.
		public Point(){}
		public Point(int x, int y) 
		{ 
			this.x = x; this.y = y;
			desc = new PointDesc("NoName");
		} 
		public Point(int x, int y, string petname)
		{
			this.x = x; 
			this.y = y;
			desc = new PointDesc(petname);
		}

		// The sole method of ICloneable.
		public object Clone()
		{
			// return this.MemberwiseClone();
 
			// Now we need to adjust for the PointDesc type.
			Point copyPt = new Point();
			copyPt.x = this.x;
			copyPt.y = this.y;

			PointDesc copyPtDesc = new PointDesc(this.desc.petName);
			copyPtDesc.petName = this.desc.petName;
			copyPtDesc.creationDate = this.desc.creationDate;

			copyPt.desc = copyPtDesc;
			return copyPt;		 
 
		}

		// Override Object.ToString().
		public override string ToString()
		{
			return "X: " + x + " Y: " + y + 
				" PetName: " + desc.petName +
				" Time of creation: " + desc.CreationTime();
		}
	}
	#endregion 
}
