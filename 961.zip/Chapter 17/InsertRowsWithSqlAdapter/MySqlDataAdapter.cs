using System;
using System.Data;
using System.Data.SqlClient;

namespace InsertRowsWithAdapter
{ 
	public class MySqlDataAdapter
	{
		#region Print table helper f(x)
		public static void PrintTable(DataSet ds)
		{
			// Print out results from table.
			Console.WriteLine("Here is what we have right now:\n");
			DataTable invTable = ds.Tables["Inventory"];

			// Print the Column names.
			for(int curCol= 0; curCol< invTable.Columns.Count; curCol++)
			{
				Console.Write(invTable.Columns[curCol].ColumnName.Trim() + "\t");
			}
			Console.WriteLine();

			// Print each cell.
			for(int curRow = 0; curRow < invTable.Rows.Count; curRow++)
			{
				for(int curCol= 0; curCol< invTable.Columns.Count; curCol++)					
				{
					Console.Write(invTable.Rows[curRow][curCol].ToString().Trim()+ "\t");				
				}
				Console.WriteLine();
			}
			Console.WriteLine();
		}
		#endregion
	
		public static void Main()
		{
			// Create a connection and adapter.
			SqlConnection cn = new SqlConnection("server=(local);uid=sa;pwd=;database=Cars");
			SqlDataAdapter dAdapt = new SqlDataAdapter("Select * from Inventory", cn);
			
			// Kill record we inserted.
			cn.Open();
			SqlCommand killCmd = new SqlCommand("DELETE FROM Inventory WHERE CarID = '1111'", cn);
			killCmd.ExecuteNonQuery();
			cn.Close();

			#region create insert logic / params
			// Build the insert Command
			dAdapt.InsertCommand = new SqlCommand("INSERT INTO Inventory (CarID, Make, Color, PetName) VALUES (@CarID, @Make, @Color, @PetName)", cn);

			// Step 4: Build parameters for each column in Inventory table.
			SqlParameter workParam = null;
			workParam = dAdapt.InsertCommand.Parameters.Add(new SqlParameter("@CarID", SqlDbType.Int));
			workParam.SourceColumn = "CarID";
			workParam.SourceVersion = DataRowVersion.Current;

			workParam = dAdapt.InsertCommand.Parameters.Add(new SqlParameter("@Make", SqlDbType.VarChar));
			workParam.SourceColumn = "Make";
			workParam.SourceVersion = DataRowVersion.Current;

			workParam = dAdapt.InsertCommand.Parameters.Add(new SqlParameter("@Color", SqlDbType.VarChar));
			workParam.SourceColumn = "Color";
			workParam.SourceVersion = DataRowVersion.Current;

			workParam = dAdapt.InsertCommand.Parameters.Add(new SqlParameter("@PetName", SqlDbType.VarChar));
			workParam.SourceColumn = "PetName";
			workParam.SourceVersion = DataRowVersion.Current;
			#endregion 

			// Fill initial data set
			DataSet myDS = new DataSet();
			dAdapt.Fill(myDS, "Inventory");
			PrintTable(myDS);

			// Add new row.
			DataRow newRow = myDS.Tables["Inventory"].NewRow();
			newRow["CarID"] = 1111;
			newRow["Make"] = "SlugBug";
			newRow["Color"] = "Pink";
			newRow["PetName"] = "Cranky";
			myDS.Tables["Inventory"].Rows.Add(newRow);

			// Send back to database and reprint.
			try
			{
				dAdapt.Update(myDS, "Inventory");
				myDS.Dispose();
				myDS = new DataSet();
				dAdapt.Fill(myDS, "Inventory");
				PrintTable(myDS);
			}
			catch(Exception e)
			{
				Console.Write(e.ToString());
			}			
		}
	}
}

