namespace SharedLibClient
{
using System;
using SharedAssembly;

public class SharedAsmUser
{
    public static int Main(string[] args)
    {
		VWMiniVan v = new VWMiniVan();
		v.Play60sTunes();
        return 0;
    }
}
}
