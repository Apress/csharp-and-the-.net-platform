using System;
using System.Collections;
using System.Collections.Specialized;

namespace CollectionTypes
{
	class CollectionApp
	{
		public static void WashCar(Car c)
		{
			Console.WriteLine("Cleaning {0}", c.PetName);
		}

		static void Main(string[] args)
		{
			#region Fun with ArrayList
			// Create ArrayList and fill with some initial values.
			Console.WriteLine("***** Fun with ArrayList *****");
			ArrayList carArList = new ArrayList();
			carArList.AddRange(new Car[] { new Car("Fred", 90, 10), 
			  new Car("Mary", 100, 50), new Car("MB", 190, 0)});
			Console.WriteLine("Items in carArList: {0}", carArList.Count);
	
			// Print out current values. 
			foreach(Car c in carArList)
			{
				Console.WriteLine("Car pet name: {0}", c.PetName);	
			}
			
			// Insert a new item.
			Console.WriteLine("-> Inserting new item");
			carArList.Insert(2, new Car("TheNewCar", 0, 0));
			Console.WriteLine("Items in carArList: {0}", carArList.Count);

			// Get object array from ArrayList & print again.
			object[] arrayOfCars = carArList.ToArray();
			for(int i = 0; i < arrayOfCars.Length; i++)
			{
				Console.WriteLine("Car pet name: {0}", 
					((Car)arrayOfCars[i]).PetName);
			}
			#endregion

			#region Fun with Queue
			Console.WriteLine("\n***** Fun with Queue *****");
			// Now make a Q with three items.
			Queue carWashQ = new Queue();
			carWashQ.Enqueue(new Car("FirstCar", 0, 0));
			carWashQ.Enqueue(new Car("SecondCar", 0, 0));
			carWashQ.Enqueue(new Car("ThirdCar", 0, 0));

			// Peek at first car in Q.
			Console.WriteLine("First in Q is {0}",
				((Car)carWashQ.Peek()).PetName);
			
			// Remove each item from Q.
			WashCar((Car)carWashQ.Dequeue());
			WashCar((Car)carWashQ.Dequeue());
			WashCar((Car)carWashQ.Dequeue());

			// Try to de-Q again?
			try
			{
				WashCar((Car)carWashQ.Dequeue());
			}
			catch(Exception e)
			{ Console.WriteLine("Error!! {0}", e.Message);}
			#endregion

			#region Fun with Stack
			Console.WriteLine("\n***** Fun with Stack *****");
			Stack stringStack = new Stack();
			stringStack.Push("One");
			stringStack.Push("Two");
			stringStack.Push("Three");

			// Now look at the top item.
			Console.WriteLine("Top item is: {0}", stringStack.Peek());
			Console.WriteLine("Popped off {0}", stringStack.Pop());
			Console.WriteLine("Top item is: {0}", stringStack.Peek());
			Console.WriteLine("Popped off {0}", stringStack.Pop());
			Console.WriteLine("Top item is: {0}", stringStack.Peek());
			Console.WriteLine("Popped off {0}", stringStack.Pop());

			try
			{
				Console.WriteLine("Top item is: {0}", stringStack.Peek());
				Console.WriteLine("Popped off {0}", stringStack.Pop());
			}
			catch(Exception e)
			{ Console.WriteLine("Error!! {0}\n", e.Message);}

			#endregion

		}
	}
}
