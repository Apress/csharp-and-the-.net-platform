using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;

// Need to add this.
using System.Drawing.Imaging;

using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace GdiPlusApp
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.TextBox TextBox3;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.TextBox txtRight;
		protected System.Web.UI.WebControls.TextBox txtBottom;
		protected System.Web.UI.WebControls.TextBox txtLeft;
		protected System.Web.UI.WebControls.TextBox txtTop;
		protected System.Web.UI.WebControls.Label lblPageText;
		protected System.Web.UI.WebControls.Label lblRight;
		protected System.Web.UI.WebControls.Label lblBottom;
		protected System.Web.UI.WebControls.Label lblTop;
		protected System.Web.UI.WebControls.Label lblInstructions;
		protected System.Web.UI.WebControls.Label lblMsg;
		protected System.Web.UI.WebControls.Button btnMakeImage;
		protected System.Web.UI.WebControls.Label lblLeft;
		protected System.Web.UI.WebControls.Image imgTheImage;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DropDownList lstColors;
		protected System.Web.UI.WebControls.TextBox txtMessage;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				imgTheImage.Visible = false;
				
				// Load the list box with all colors.
				Array theColors = Enum.GetNames(typeof(KnownColor));
				lstColors.DataSource = theColors;
				lstColors.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnMakeImage.Click += new System.EventHandler(this.btnMakeImage_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnMakeImage_Click(object sender, System.EventArgs e)
		{
			try
			{
				// Get color from list box.
				KnownColor c = (KnownColor)Enum.Parse(typeof(KnownColor),
					lstColors.SelectedValue);
				SolidBrush br = new SolidBrush(Color.FromKnownColor(c));

				// Make a Bitmap
				Bitmap myBitmap = new Bitmap(200, 200);
				Graphics g = Graphics.FromImage(myBitmap);

				// Render some stuff.			
				g.FillRectangle(br, 0, 0, 200, 200);
				g.DrawEllipse(Pens.Blue, 			
					int.Parse(txtLeft.Text), 
					int.Parse(txtTop.Text), 
					int.Parse(txtRight.Text),
					int.Parse(txtBottom.Text));
				g.DrawString(txtMessage.Text, 
					new Font("Times New Roman", 12, FontStyle.Bold), 
					Brushes.Black, 50, 50);

				// Save image to temp.
				myBitmap.Save(@"C:\Temp\test.gif", ImageFormat.Gif);
				myBitmap.Dispose();
				g.Dispose();		
				imgTheImage.ImageUrl = @"C:\Temp\test.gif";
				imgTheImage.Visible = true;
			}
			catch
			{
				Response.Write("Yo! Fill in data and try again...");
				Response.End();
			}
		}
	}
}
