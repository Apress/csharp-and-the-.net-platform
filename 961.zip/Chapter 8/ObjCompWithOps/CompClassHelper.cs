// Redefined as nested class in the Car class!

/*
using System;
using System.Collections;

namespace ObjComp
{
	public class SortByPetName : IComparer
	{
		public SortByPetName(){}

		// IComparer impl.
		int IComparer.Compare(object o1, object o2)
		{
			Car t1 = (Car)o1;
			Car t2 = (Car)o2;
			return String.Compare(t1.PetName, t2.PetName);
		}
	}
}
*/
 
