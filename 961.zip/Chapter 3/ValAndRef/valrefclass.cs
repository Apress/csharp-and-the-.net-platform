using System;

namespace ValandRef
{
	#region Value and reference types for the program
	// Change struct to class to see the different behaviors.
	struct FOO	
	{
		public int x, y;
	}

	// This type will be used
	// within a struct.
	class TheRefType
	{
		public string x;
		public TheRefType(string s)
		{x = s;}
	}

	// This stuct has members that
	// are value types and ref types.
	struct InnerRef
	{
		public TheRefType refType; // Ref type.
		public int structData;  // Val type
		public InnerRef(string s)
		{
			refType = new TheRefType(s);
			structData = 9;
		}
	}
	#endregion

	class ValRefClass
	{
		public static int Main(string[] args)
		{
			Console.WriteLine("***** Value types & Ref Types *****");
			FOO f1 = new FOO();
			f1.x = 100;
			f1.y = 100;
        
			Console.WriteLine("-> Assigning f2 to f1.");
			FOO f2 = f1;
		
			// Here is F1.
			Console.WriteLine("F1.x = {0}", f1.x);
			Console.WriteLine("F1.y = {0}", f1.y);
			
			// Here is F2.
			Console.WriteLine("F2.x = {0}", f2.x);
			Console.WriteLine("F2.y = {0}", f2.y);

			// Change f2.x.  This will NOT change f1.x.
			Console.WriteLine("-> Changing f2.x");	
			f2.x = 900;

			// Print again.
			Console.WriteLine("-> Here are the X�s again...");
			Console.WriteLine("F2.x = {0}", f2.x);
			Console.WriteLine("F1.x = {0}\n", f1.x);

			// Make val type that contains ref type.
			Console.WriteLine("***** Val type containing Ref Type *****");
			// Make value type that contains ref type.
			Console.WriteLine("-> Making InnerRef type and setting structData to 666");
			InnerRef valWithRef = new InnerRef("Initial value");
			valWithRef.structData = 666;

			// Now assign a new InnerRef
			Console.WriteLine("-> Assigning valWithRef2 to valWithRef");
			InnerRef valWithRef2; 
			valWithRef2 = valWithRef;

			// Change the value of the internal reference type.
			Console.WriteLine("-> Changing all values of valWithRef2");
			valWithRef2.refType.x = "I am NEW!";
			valWithRef2.structData = 777;

			// Print everything.
			Console.WriteLine("\nValues after change:");
			Console.WriteLine("-> valWithRef.refType.x is {0}", valWithRef.refType.x);
			Console.WriteLine("-> valWithRef2.refType.x is {0}", valWithRef2.refType.x);
			Console.WriteLine("-> valWithRef.structData is {0}", valWithRef.structData);        
			Console.WriteLine("-> valWithRef2.structData is {0}", valWithRef2.structData);
			return 0;
		}
	}
}