using System;

namespace Containment
{
	public class CarApp
	{
		public static int Main(string[] args)
		{		
			// Make a car.
			Car c1;
			c1 = new Car("SlugBug", 100, 10);

			// Jam some tunes.
			Console.WriteLine("***** Turing on radio for SlugBug *****");
			c1.CrankTunes(true);

			// Speed up.
			Console.WriteLine("\n***** Speeding up *****");
			for(int i = 0; i < 10; i++)
				c1.SpeedUp(20);

			// Shut down.
			Console.WriteLine("\n***** Turing off radio for SlugBug *****");
			c1.CrankTunes(false);
			return 0;
		}
	}
}
