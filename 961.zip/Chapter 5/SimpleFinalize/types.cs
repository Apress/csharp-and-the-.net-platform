using System;

namespace SimpleFinalize
{
	class FinalizedCar
	{
		~FinalizedCar()
		{
			Console.WriteLine("=> Finalizing car...");
		}
	}

	class FinalizeApp
	{
		static void Main(string[] args)
		{
			Console.WriteLine("***** Making object *****");
			FinalizedCar fc = new FinalizedCar();
			Console.WriteLine("***** Exiting main *****");
		}
	}
}
