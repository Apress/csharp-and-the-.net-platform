using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DataGridApp
{
	public class DataGridPage: System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DataGrid myDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Fill the grid with records.
			if(!IsPostBack)
			{
				UpdateGrid();
			}
		}

		private void UpdateGrid()
		{
			DataSet myDS = new DataSet();
			SqlConnection c = new 
				SqlConnection("Server=localhost;UID=sa;PWD=;Database=Cars");
			c.Open();

			SqlCommand s = new SqlCommand("Select * from Inventory", c);
			SqlDataAdapter d = new SqlDataAdapter(s);
			d.Fill(myDS, "Inventory");
			myDataGrid.DataSource = myDS.Tables["Inventory"];
			myDataGrid.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.myDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.myDataGrid_PageIndexChanged);
			this.myDataGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.myDataGrid_CancelCommand);
			this.myDataGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.myDataGrid_EditCommand);
			this.myDataGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.myDataGrid_UpdateCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void myDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			myDataGrid.CurrentPageIndex = e.NewPageIndex;
			UpdateGrid();		
		}

		private void myDataGrid_CancelCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// Disable the edit.
			myDataGrid.EditItemIndex = -1;
			UpdateGrid(); 		
		}

		private void myDataGrid_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// Tell grid which row is active. 
			myDataGrid.EditItemIndex = e.Item.ItemIndex;
			UpdateGrid(); 		
		}

		private void myDataGrid_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// Get new info from edits.
			int theCarID;
			TextBox newMake, newColor, newPetName;
			theCarID = (int)myDataGrid.DataKeys[e.Item.ItemIndex];
			newMake = (TextBox)e.Item.Cells[1].Controls[0];
			newColor = (TextBox)e.Item.Cells[2].Controls[0];
			newPetName = (TextBox)e.Item.Cells[3].Controls[0];

			// Build a SQL string based on info.
			string sqlUpdate = string.Format
				("Update Inventory Set Make='{0}', Color='{1}', PetName='{2}' Where CarID='{3}'",
				newMake.Text.Trim(), newColor.Text.Trim(), 
				newPetName.Text.Trim(), theCarID);		

			// Submit to DB.
			SqlConnection c = new   
				SqlConnection("Server=localhost;UID=sa;PWD=;Database=Cars");
			c.Open();
			SqlCommand s = new SqlCommand(sqlUpdate,c);
			s.ExecuteNonQuery();
			c.Close();

			// Get out of edit mode.
			myDataGrid.EditItemIndex = -1;
			UpdateGrid();		
		}
	}
}
