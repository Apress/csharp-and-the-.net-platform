'You must set a reference to the IndexerCodeLibrary 
'to get this project to compile!  This process is 
'detailed in chapter 9.

Imports IndexerCodeLibrary

Module CarApp
    Sub Main()
        Console.WriteLine("***** VB .NET client using C# indexer *****")
        Dim carLot As New Cars()
        carLot.Item(0) = New Car("MB", 150, 40)
        carLot(1) = New Car("Daisy", 130, 40)

        Dim c As Car
        For Each c In carLot
            Console.WriteLine("Name: {0}, Max Speed: {1}", _
                c.PetName, c.MaxSpeed)
        Next
    End Sub
End Module
