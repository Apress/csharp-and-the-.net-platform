using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DataColumns
{
    public class DCForm : System.Windows.Forms.Form
    {
        private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button btnAutoCol;
		private System.Windows.Forms.Button btnColumn;

        public DCForm()
        {
            InitializeComponent();
			CenterToScreen();
        }

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Init component stuff
		private void InitializeComponent()
		{
			this.btnColumn = new System.Windows.Forms.Button();
			this.btnAutoCol = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnColumn
			// 
			this.btnColumn.Location = new System.Drawing.Point(8, 16);
			this.btnColumn.Name = "btnColumn";
			this.btnColumn.Size = new System.Drawing.Size(344, 40);
			this.btnColumn.TabIndex = 0;
			this.btnColumn.Text = "Build and manipulate basic DataColumn";
			this.btnColumn.Click += new System.EventHandler(this.btnColumn_Click);
			// 
			// btnAutoCol
			// 
			this.btnAutoCol.Location = new System.Drawing.Point(8, 80);
			this.btnAutoCol.Name = "btnAutoCol";
			this.btnAutoCol.Size = new System.Drawing.Size(344, 40);
			this.btnAutoCol.TabIndex = 1;
			this.btnAutoCol.Text = "Auto Increment Column";
			this.btnAutoCol.Click += new System.EventHandler(this.btnAutoCol_Click);
			// 
			// DCForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(366, 147);
			this.Controls.Add(this.btnAutoCol);
			this.Controls.Add(this.btnColumn);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Name = "DCForm";
			this.Text = "DataColumn Form";
			this.ResumeLayout(false);

		}
		#endregion 

		#region Button click handlers
		protected void btnAutoCol_Click (object sender, System.EventArgs e)
		{
			// Make a data column which maps to an int32.
			DataColumn myColumn = new DataColumn();
			myColumn.ColumnName = "Foo";
			myColumn.DataType = System.Type.GetType("System.Int32");

			// Set the auto increment behavior.
			myColumn.AutoIncrement = true;
			myColumn.AutoIncrementSeed = 500;
			myColumn.AutoIncrementStep = 12;
			
			// Add this column to a new DataTable.
			DataTable myTable = new DataTable("MyTable");
			myTable.Columns.Add(myColumn);
			
			// Add 20 rows.
			DataRow r;
			for(int i =0; i < 20; i++)
			{
				r = myTable.NewRow();
				myTable.Rows.Add(r);
			}

			// Now list the value in each row.
			string temp = "";
			DataRowCollection rows = myTable.Rows;
			for(int i = 0;i < myTable.Rows.Count; i++)
			{
				DataRow currRow = rows[i];
				temp += currRow["Foo"] + " ";
			}
			MessageBox.Show(temp, "These values brought ala auto-increment");
		}

		protected void btnColumn_Click (object sender, System.EventArgs e)
		{
			// Create and set a single DataColumn.
			DataColumn colFName = new DataColumn("FirstName", 
												 Type.GetType("System.String"));
			colFName.ReadOnly = true;
			colFName.Caption = "First Name";
			colFName.ColumnName = "FirstName";

			// Get a bunch of values.
			string temp = "Column type: " + colFName.DataType + "\n" +
						  "Read only? " + colFName.ReadOnly + "\n" +
						  "Caption: " + colFName.Caption + "\n" +
						  "Column Name: " + colFName.ColumnName + "\n" + 
						  "Nulls allowed? " + colFName.AllowDBNull;

			MessageBox.Show(temp, "Column properties");
		}
		#endregion

        public static void Main(string[] args) 
        {
            Application.Run(new DCForm());
        }
    }
}
