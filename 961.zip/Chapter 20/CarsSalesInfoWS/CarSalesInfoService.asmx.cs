using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace CarSalesInfo
{
	[WebService(Namespace="http://www.intertech-inc.com/webservices",
		 Description="This Web service processes complex types")]
	public class CarSalesInfoService : System.Web.Services.WebService
	{
		private ArrayList theCars = new ArrayList();

		public CarSalesInfoService()
		{
			InitializeComponent();
			theCars.Add(new Car("Biff", "Green", "Firebird")); 
			theCars.Add(new Car("Bunny", "Pink", "Colt"));
			theCars.Add(new Car("Chuck", "Red", "BWM"));
			theCars.Add(new Car("Mary", "Red", "Viper"));
			theCars.Add(new Car("Mandy", "Tan", "Golf"));
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		#region Web methods
		[WebMethod(Description="Get current discount blurbs")]
		public string[] GetSalesTagLines()
		{
			string[] currentDeals = {"Colt prices slashed 50%!",
			                         "All BMWs come with standard 8-track",
			                         "Free Pink Caravans...just ask me!"};
			return currentDeals;
		}

		[WebMethod(Description="Sorts a list of car makes")]
		public string[] SortCarMakes(string[] theCarsToSort)
		{
			Array.Sort(theCarsToSort);
			return theCarsToSort;
		}

		[WebMethod(Description="Get details of current sales")]
		public SalesInfoDetails[] GetSalesInfoDetails()
		{
			SalesInfoDetails[] theInfo = new SalesInfoDetails[3];
			theInfo[0].info = "Colt prices slashed 50%!";
			theInfo[0].dateExpired = DateTime.Parse("12/02/04");
			theInfo[0].Url= "http://www.CarsRUs.com";

			theInfo[1].info = "All BMWs come with standard 8-track";
			theInfo[1].dateExpired = DateTime.Parse("8/11/03");
			theInfo[1].Url= "http://www.Bmws4U.com";

			theInfo[2].info = "Free Pink Caravans...just ask me!";
			theInfo[2].dateExpired = DateTime.Parse("12/01/09");
			theInfo[2].Url= "http://www.AllPinkVans.com";

			return theInfo;			 
		}	

		// Return a given car from the list.
		[WebMethod(Description = "Get a specific car from ArrayList")]
		public Car GetACarFromList(int carToGet)
		{ 
			if(carToGet <= theCars.Count)
			{ 
				return (Car) theCars[carToGet];
			} 
			throw new IndexOutOfRangeException();
		} 

		// Return the entire set of cars.
		[WebMethod(Description = "Get the ArrayList of Cars")]
		public ArrayList GetCarList()
		{ 
			return theCars;
		} 
		// Return all cars in inventory table.
		[WebMethod(Description = "Returns all autos in the Inventory table of the Cars database")]
		public DataSet GetAllCarsFromDB()
		{ 
			// Fill the DataSet with the Inventory table.
			SqlConnection sqlConn = new SqlConnection();
			sqlConn.ConnectionString = "data source=.; initial catalog=Cars;" +  
				"user id=sa; password=";
			SqlDataAdapter myDA= 
				new SqlDataAdapter("Select * from Inventory", sqlConn);
			DataSet ds = new DataSet();
			myDA.Fill(ds, "Inventory");
			return ds;
		} 
		#endregion
	}

	#region Helper structs.
	public struct SalesInfoDetails
	{
		public string info;
		public DateTime dateExpired;
		public string Url;
	}
	public struct Car
	{
		public Car(string p, string c, string m)
		{ 
			petName = p;
			carColor = c;
			carMake = m;
		}
		public string petName;
		public string carColor;
		public string carMake;
	}
	#endregion 
}
