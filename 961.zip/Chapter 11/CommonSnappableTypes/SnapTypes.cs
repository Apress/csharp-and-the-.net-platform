using System;

// The types in this namespace must
// be leveraged by a type in order to 
// be used in our extendable app.
namespace CommonSnappableTypes
{
	public interface IUseMyFunctionality
	{
		void DoIt();
	}

	[AttributeUsage(AttributeTargets.Class)]
	public class SnappableAttribute : System.Attribute
	{
		public SnappableAttribute(){}
	}
}
