using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace AppState
{
	public class AppStatePage: System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnShowAppVariables;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button btnSetNewSP;
		protected System.Web.UI.WebControls.TextBox txtNewSP;
		protected System.Web.UI.WebControls.Label lblAppVariables;

		private void Page_Load(object sender, System.EventArgs e)
		{}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnShowAppVariables.Click += new System.EventHandler(this.btnShowAppVariables_Click);
			this.btnSetNewSP.Click += new System.EventHandler(this.btnSetNewSP_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnShowAppVariables_Click(object sender, System.EventArgs e)
		{
			CarLotInfo appVars = 
				((CarLotInfo)Application["CarSiteInfo"]);

			string appState = 
				string.Format("<li>Car on sale: {0}</li>", 
				appVars.currentCarOnSale);
			appState += 
				string.Format("<li>Most popular color: {0}</li>", 
				appVars.mostPopularColorOnLot);
			appState += 
				string.Format("<li>Big shot SP: {0}</li>", 
				appVars.salesPersonOfTheMonth);

			lblAppVariables.Text = appState;
		}

		private void btnSetNewSP_Click(object sender, System.EventArgs e)
		{
			// Set the new Sales Person.
			((CarLotInfo)Application["CarSiteInfo"]).salesPersonOfTheMonth 
				= txtNewSP.Text;
		}
	}
}
