using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SimpleMdiApp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MdiForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mnuFile;
		private System.Windows.Forms.MenuItem mnuFileExit;
		private System.Windows.Forms.MenuItem mnuWindow;
		private System.Windows.Forms.MenuItem mnuArrange;
		private System.Windows.Forms.MenuItem mnuArrangeCascade;
		private System.Windows.Forms.MenuItem mnuArrangeVert;
		private System.Windows.Forms.MenuItem mnuArrangeHorizontal;
		private System.Windows.Forms.MenuItem mnuFileNew;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MdiForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuFileNew = new System.Windows.Forms.MenuItem();
			this.mnuFileExit = new System.Windows.Forms.MenuItem();
			this.mnuWindow = new System.Windows.Forms.MenuItem();
			this.mnuArrange = new System.Windows.Forms.MenuItem();
			this.mnuArrangeCascade = new System.Windows.Forms.MenuItem();
			this.mnuArrangeVert = new System.Windows.Forms.MenuItem();
			this.mnuArrangeHorizontal = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuFile,
																					  this.mnuWindow,
																					  this.mnuArrange});
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuFileNew,
																					this.mnuFileExit});
			this.mnuFile.Text = "&File";
			// 
			// mnuFileNew
			// 
			this.mnuFileNew.Index = 0;
			this.mnuFileNew.Text = "&New";
			this.mnuFileNew.Click += new System.EventHandler(this.mnuFileNew_Click);
			// 
			// mnuFileExit
			// 
			this.mnuFileExit.Index = 1;
			this.mnuFileExit.Text = "E&xit";
			this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
			// 
			// mnuWindow
			// 
			this.mnuWindow.Index = 1;
			this.mnuWindow.MdiList = true;
			this.mnuWindow.Text = "&Window";
			// 
			// mnuArrange
			// 
			this.mnuArrange.Index = 2;
			this.mnuArrange.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.mnuArrangeCascade,
																					   this.mnuArrangeVert,
																					   this.mnuArrangeHorizontal});
			this.mnuArrange.Text = "&Arrange Window";
			// 
			// mnuArrangeCascade
			// 
			this.mnuArrangeCascade.Index = 0;
			this.mnuArrangeCascade.Text = "&Cascade";
			this.mnuArrangeCascade.Click += new System.EventHandler(this.mnuArrangeCascade_Click);
			// 
			// mnuArrangeVert
			// 
			this.mnuArrangeVert.Index = 1;
			this.mnuArrangeVert.Text = "&Vertical";
			this.mnuArrangeVert.Click += new System.EventHandler(this.mnuArrangeVert_Click);
			// 
			// mnuArrangeHorizontal
			// 
			this.mnuArrangeHorizontal.Index = 2;
			this.mnuArrangeHorizontal.Text = "&Horizontal";
			this.mnuArrangeHorizontal.Click += new System.EventHandler(this.mnuArrangeHorizontal_Click);
			// 
			// MdiForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 269);
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu1;
			this.Name = "MdiForm";
			this.Text = "The MDI Application";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MdiForm());
		}

		#region event handlers.
		// Handle close event and arrange all child windows.
		private void mnuFileExit_Click(object sender, System.EventArgs e)
		{ this.Close(); }

		private void mnuArrangeCascade_Click(object sender, System.EventArgs e)
		{ LayoutMdi(MdiLayout.Cascade); }

		private void mnuArrangeVert_Click(object sender, System.EventArgs e)
		{ LayoutMdi(MdiLayout.TileVertical); }

		private void mnuArrangeHorizontal_Click(object sender, System.EventArgs e)
		{ LayoutMdi(MdiLayout.TileHorizontal); }

		private void mnuFileNew_Click(object sender, System.EventArgs e)
		{
			// Make a new child window.
			KidPrototypeForm newChild = new KidPrototypeForm();

			// Set the Parent Form of the Child window.
			newChild.MdiParent = this;

			// Display the new form.
			newChild.Show();		
		}
		#endregion 
	}
}
