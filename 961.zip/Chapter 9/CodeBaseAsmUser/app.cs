using System;
using SharedAssembly;

namespace CodeBaseAsmUser
{
	class CodeBaseUser
	{
		static void Main(string[] args)
		{
			// Just enough to activate the type.
			VWMiniVan v = new VWMiniVan();
			v.CrankGoodTunes(BandName.deftones);
		}
	}
}
