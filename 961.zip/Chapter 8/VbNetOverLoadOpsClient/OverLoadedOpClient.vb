Imports OverLoadOpsCodeLibrary

Module OverLoadedOpClient
    Sub Main()
        Console.WriteLine("***** VB .NET Client using overloaded op special names *****")
        Dim p1 As Point
        p1.x = 200
        p1.y = 9

        Dim p2 As Point
        p2.x = 9
        p2.y = 983

        Dim bigPoint = Point.op_Addition(p1, p2)
        Console.WriteLine("Big point is {0}", bigPoint)
    End Sub
End Module
