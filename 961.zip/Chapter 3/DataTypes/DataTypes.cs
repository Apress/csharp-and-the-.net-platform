using System;

namespace DataTypes
{
class MyDataTypes
{
    public static int Main(string[] args)
    {
		// Test value semantics.
		Console.WriteLine("***** Numerical types use value based semantics *****");
		System.Int32 intA = 1001;
		System.Int32 intB = 1000;
		if(intA == intB)
			Console.WriteLine("Same value!\n");
		else
			Console.WriteLine("Not the same value!\n");

		#region Working with System.UInt16
		// Working with UInt16 as a wrapper.
		Console.WriteLine("***** Some (not all) members of System.UInt16 *****");
		System.UInt16 myUInt16 = 30000;
		Console.WriteLine("Max for an UInt16 is: {0}", UInt16.MaxValue);
		Console.WriteLine("Min for an UInt16 is: {0}", UInt16.MinValue);
		Console.WriteLine("Your value is: {0}", myUInt16.ToString());
		Console.WriteLine("I am a: {0}", myUInt16.GetType().ToString());
		
		// Now in UInt16 shorthand (e.g. a ushort).
		ushort myOtherUInt16 = 12000;
		Console.WriteLine("Your value is: {0}", myOtherUInt16.ToString());
		Console.WriteLine("I am a: {0}\n", myOtherUInt16.GetType().ToString());
		#endregion

		#region Work with System.Double
		// Some members of System.Double.
		Console.WriteLine("***** Some (not all) members of System.Double *****");
		Console.WriteLine("-> double.Epsilon: {0}",
			double.Epsilon);
		Console.WriteLine("-> double.PositiveInfinity: {0}",
			double.PositiveInfinity);
		Console.WriteLine("-> double.NegativeInfinity: {0}",
			double.NegativeInfinity);
		Console.WriteLine("-> double.MaxValue: {0}",
			double.MaxValue);
		Console.WriteLine("-> double.MinValue: {0}",
			double.MinValue);
			#endregion 

		#region Work with System.Boolean
		// Some members of System.Boolean.
		Console.WriteLine("\n***** Some members of System.Boolean *****");
		Console.WriteLine("-> bool.FalseString: {0}",
			bool.FalseString);
		Console.WriteLine("-> bool.TrueString: {0}",
			bool.TrueString);
			#endregion 

		#region Work with System.ULong
		// Some members of System.ULong.
		Console.WriteLine("\n***** Some (not all) members of System.ULong *****");
		Console.WriteLine("-> ulong.MaxValue: {0}",
			ulong.MaxValue);
		Console.WriteLine("-> ulong.MinValue: {0}\n",
			ulong.MinValue);
			#endregion 

		#region Members of System.Char
		// Some 'other' members of System.Char.
		Console.WriteLine("***** Interesting members of System.Char ****");
		Console.WriteLine("-> char.IsDigit('K'): {0}", 
			char.IsDigit('K'));
		Console.WriteLine("-> char.IsDigit('9'): {0}", 
			char.IsDigit('9'));
		Console.WriteLine("-> char.IsLetter('10', 1): {0}", 
			char.IsLetter("10", 1));
		Console.WriteLine("-> char.IsLetter('p'): {0}", 
			char.IsLetter('p'));
		Console.WriteLine("-> char.IsWhiteSpace('Hello There', 5): {0}", 
			char.IsWhiteSpace("Hello There", 5));
		Console.WriteLine("-> char.IsWhiteSpace('Hello There', 6): {0}", 
			char.IsWhiteSpace("Hello There", 6));
		Console.WriteLine("-> char.IsLetterOrDigit('?'): {0}", 
			char.IsLetterOrDigit('?'));
		Console.WriteLine("-> char.IsPunctuation('!'): {0}", 
			char.IsPunctuation('!'));
		Console.WriteLine("-> char.IsPunctuation('>'): {0}", 
			char.IsPunctuation('>'));
		Console.WriteLine("-> char.IsPunctuation(','): {0}", 
			char.IsPunctuation(','));

			#endregion
							
		#region Parsing strings to get data types.
		// Parsing a string to obtain a system type"
		Console.WriteLine("\n***** Parsing strings to create data types! ****");
		bool myBool = bool.Parse("True");
		Console.WriteLine("-> Value of myBool: {0}", myBool);

		double myDbl = double.Parse("99.884");
		Console.WriteLine("-> Value of myDbl: {0}", myDbl);

		int myInt = int.Parse("8");
		Console.WriteLine("-> Value of myInt: {0}", myInt);

		char myChar = char.Parse("w");
		Console.WriteLine("-> Value of myChar: {0}\n", myChar);
		#endregion 

		return 0;
    }
}
}
