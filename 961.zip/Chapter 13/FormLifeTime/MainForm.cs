using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace FormLifeTime
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private string lifeTimeInfo;

		public MainForm()
		{
			InitializeComponent();

			// Handle events.
			this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.Closed += new System.EventHandler(this.MainForm_Closed);
			this.Activated += new System.EventHandler(this.MainForm_Activated);
			this.Deactivate += new System.EventHandler(this.MainForm_Deactivate);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			MessageBox.Show(lifeTimeInfo, "Life time events");
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(280, 177);
			this.Name = "MainForm";
			this.Text = "Main Form";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		#region event handlers.
		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			lifeTimeInfo += "Closing event\n";
			DialogResult dr = MessageBox.Show("Do you REALLY want to close this app?",
				"Closing event!", MessageBoxButtons.YesNo);
			if(dr == DialogResult.No)
				e.Cancel = true;
			else
				e.Cancel = false;		
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{ lifeTimeInfo += "Load event\n"; }

		private void MainForm_Activated(object sender, System.EventArgs e)
		{ lifeTimeInfo += "Activate event\n"; }

		private void MainForm_Deactivate(object sender, System.EventArgs e)
		{ lifeTimeInfo += "Deactivate event\n"; }
		
		private void MainForm_Closed(object sender, System.EventArgs e)
		{ lifeTimeInfo += "Closed event\n"; }
		#endregion 
	}
}
