using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CarSalesInfoClient.localhost;

namespace CarSalesInfoClient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class mainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid inventoryDG;
		private System.Windows.Forms.Button btnGetAllDetails;
		private System.Windows.Forms.ListBox lstCarSaleTagLines;
		private System.Windows.Forms.Label label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public mainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.inventoryDG = new System.Windows.Forms.DataGrid();
			this.btnGetAllDetails = new System.Windows.Forms.Button();
			this.lstCarSaleTagLines = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.inventoryDG)).BeginInit();
			this.SuspendLayout();
			// 
			// inventoryDG
			// 
			this.inventoryDG.CaptionText = "The Inventory Table ala XML Web Service";
			this.inventoryDG.DataMember = "";
			this.inventoryDG.FlatMode = true;
			this.inventoryDG.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.inventoryDG.Location = new System.Drawing.Point(8, 176);
			this.inventoryDG.Name = "inventoryDG";
			this.inventoryDG.Size = new System.Drawing.Size(272, 112);
			this.inventoryDG.TabIndex = 0;
			// 
			// btnGetAllDetails
			// 
			this.btnGetAllDetails.Location = new System.Drawing.Point(8, 304);
			this.btnGetAllDetails.Name = "btnGetAllDetails";
			this.btnGetAllDetails.Size = new System.Drawing.Size(272, 23);
			this.btnGetAllDetails.TabIndex = 1;
			this.btnGetAllDetails.Text = "Display Sales Info Details";
			this.btnGetAllDetails.Click += new System.EventHandler(this.btnGetAllDetails_Click);
			// 
			// lstCarSaleTagLines
			// 
			this.lstCarSaleTagLines.Location = new System.Drawing.Point(16, 48);
			this.lstCarSaleTagLines.Name = "lstCarSaleTagLines";
			this.lstCarSaleTagLines.Size = new System.Drawing.Size(256, 95);
			this.lstCarSaleTagLines.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(200, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Here are the current tag lines";
			// 
			// mainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(288, 342);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lstCarSaleTagLines);
			this.Controls.Add(this.btnGetAllDetails);
			this.Controls.Add(this.inventoryDG);
			this.Name = "mainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CarsSalesInfoWS Client Form";
			this.Load += new System.EventHandler(this.mainForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.inventoryDG)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new mainForm());
		}

		private void mainForm_Load(object sender, System.EventArgs e)
		{
			CarSalesInfoService ws = new CarSalesInfoService();
			string[] tagLines = ws.GetSalesTagLines();
			foreach(string s in tagLines)
				lstCarSaleTagLines.Items.Add(s); 
		
			// Fill data grid.
			DataSet ds = ws.GetAllCarsFromDB();
			inventoryDG.DataSource = ds.Tables["Inventory"];
		}

		private void btnGetAllDetails_Click(object sender, System.EventArgs e)
		{
			CarSalesInfoService ws = new CarSalesInfoService();
			SalesInfoDetails[] theSkinny = ws.GetSalesInfoDetails();
			foreach(SalesInfoDetails s in theSkinny)
			{
				string d = string.Format("Info: {0}\nURL:{1}\nExpiration Date:{2}",
					s.info, s.Url, s.dateExpired);
				MessageBox.Show(d, "Details");			
			}		
		}
	}
}
