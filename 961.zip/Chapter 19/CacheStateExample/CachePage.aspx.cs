using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CacheState
{
	public class CachePage : System.Web.UI.Page
	{
		#region member vars...
		protected System.Web.UI.WebControls.DataGrid carsDataGrid;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.TextBox txtCarPetName;
		protected System.Web.UI.WebControls.TextBox txtCarColor;
		protected System.Web.UI.WebControls.TextBox txtCarMake;
		protected System.Web.UI.WebControls.TextBox txtCarID;
		protected System.Web.UI.WebControls.Button btnAddNewCar;
		protected System.Web.UI.WebControls.Label Label6;
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				carsDataGrid.DataSource = 
					(DataSet)Cache["AppDataSet"];
				carsDataGrid.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnAddNewCar.Click += new System.EventHandler(this.btnAddNewCar_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnAddNewCar_Click(object sender, System.EventArgs e)
		{
			// Simply update the Inventory table
			// and call RefreshGrid().
			SqlConnection cn = new SqlConnection();
			cn.ConnectionString = 
				"User ID=sa;Pwd=;Initial Catalog=Cars;" + 
				"Data Source=(local)";
			cn.Open();

			string sql;
			SqlCommand cmd;

			// Insert new Car.
			sql = string.Format
				("INSERT INTO Inventory(CarID, Make, Color, PetName) VALUES" +
				"('{0}', '{1}', '{2}', '{3}')", 
				txtCarID.Text, txtCarMake.Text, 
				txtCarColor.Text, txtCarPetName.Text);
			cmd = new SqlCommand(sql, cn);
			cmd.ExecuteNonQuery(); 
			cn.Close();
			RefreshGrid();
		}

		private void RefreshGrid()
		{
			// Populate grid.
			SqlConnection cn = new SqlConnection();
			cn.ConnectionString = 
				"User ID=sa;pwd=;Initial Catalog=Cars;" + 
				"Data Source=(local)";
			cn.Open();
			SqlCommand cmd = new SqlCommand("Select * from Inventory", cn);
			carsDataGrid.DataSource = cmd.ExecuteReader();
			carsDataGrid.DataBind();
			cn.Close();
		}
	}
}
