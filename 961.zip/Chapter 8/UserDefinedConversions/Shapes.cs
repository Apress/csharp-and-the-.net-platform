using System;

namespace UserDefinedConversions
{
	#region The Rectangle
	public struct Rectangle
	{
		public int width, height;
		public void Draw()
		{ Console.WriteLine("Drawing a rect.");}

		// Rectangles can be converted 
		// into squares.
//		public static explicit operator Rectangle(Square s)
//		{
//			Rectangle r;
//			r.height = s.sideLength;
//			r.width = s.sideLength;
//			return r;		
//		}
		
 		public static implicit operator Rectangle(Square s)
 		{
 			Rectangle r;
 			r.height = s.sideLength;
 			r.width = s.sideLength;
 			return r;
 		}

		public override string ToString()
		{
			return string.Format("[Width = {0}; Height = {1}]", 
				width, height);
		}
 	}
	#endregion 

	#region The Square
	public struct Square
	{
		// Can call as:
		// Square sq2 = (Square)90;
		// or as:
		// Square sq2 = 90;
		public static implicit operator Square(int sideLength)
		{
			Square newSq;
			newSq.sideLength = sideLength;
			return newSq;
		}
		
		// Must call as:
		// int side = (Square)mySquare;
		public static explicit operator int (Square s)
		{
			return s.sideLength;
		}
		
		public int sideLength;
		public void Draw()
		{ Console.WriteLine("Drawing a square.");}

		public override string ToString()
		{
			return string.Format("[SideLength = {0}]", sideLength);
		}
	}
	#endregion
}
