using System;

namespace ObjClone
{
	public class CloneApp
	{
		public static int Main(string[] args)
		{
			// Two references to same object!
			Console.WriteLine("***** Assigning points *****");
			Point p1 = new Point(50, 50, "Fred");
			Point p2 = p1;
			p2.x = 0;

			// Print each obj.
			Console.WriteLine("p1 is {0}", p1);
			Console.WriteLine("p2 is {0}\n", p2);

			// Now Clone object.
			Console.WriteLine("***** Cloning p3 and holding in p4 *****");
			Point p3 = new Point(100, 100, "Jane");
			Point p4 = (Point)p3.Clone();
		
			Console.WriteLine("-> Before pet name modification");
			Console.WriteLine("p3: {0}", p3);
			Console.WriteLine("p4: {0}", p4);

			p4.desc.petName = "XXXXX";
		
			Console.WriteLine("\n-> After pet name modification");
			Console.WriteLine("p3: {0}", p3);
			Console.WriteLine("p4: {0}\n", p4);
			return 0;
		}

	}
}
