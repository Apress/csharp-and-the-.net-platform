using System;

namespace Shapes
{
	public class ShapesApp
	{
		// I'll Draw anything!
		public static void DrawThisShapeIn3D(IDraw3D itf3d)
		{
			Console.WriteLine("-> Drawing IDraw3D compatible type");
			itf3d.Draw();
		}
	
		public static int Main(string[] args)
		{
			Console.WriteLine("***** Obtaining Interface References *****");

			#region Cast for interface 
			// First way to obtain an interface:
			Circle c = new Circle("Mitch");
			IPointy itfPt; 
			try
			{
				itfPt = (IPointy)c;
			}
			catch(InvalidCastException e)
			{Console.WriteLine("OOPS!  Not pointy...");}
			#endregion 

			#region Use 'as' to get interface
			// Second way to obtain an interface:
			Hexagon hex = new Hexagon("Fran");
			IPointy itfPt2; 
			itfPt2 = hex as IPointy;
			if(itfPt2 != null)
				Console.WriteLine("Got interface using as keyword");
			else
				Console.WriteLine("OOPS!  Not pointy...");
			#endregion

			#region Use 'is' to get interface
			// Third way to grab an interface.
			Triangle t = new Triangle();
			if(t is IPointy)
				Console.WriteLine("Got interface using is keyword");
			else	
				Console.WriteLine("OOPS!  Not pointy...");
			#endregion 

			#region Trigger interface member from object ref
			// Trigger GetNumberOfPoints() from object reference.
			Console.WriteLine("Getting number of points from hex object...");
			Hexagon h2 = new Hexagon();
			if(h2 is IPointy)
				Console.WriteLine("Points: {0}", h2.GetNumberOfPoints());
			#endregion

			// The C# base class pointer trick.
			Console.WriteLine("\n***** Determining interface support at runtime *****");

			Shape[] s = {new Hexagon(), new Circle(), 
						 new Triangle("Joe"), new Circle("JoJo")};
			for(int i = 0; i < s.Length; i++)
			{				
				s[i].Draw();

				// Who's pointy?
				if(s[i] is IPointy)
					Console.WriteLine("-> Points: {0}", ((IPointy)s[i]).GetNumberOfPoints());
				else
					Console.WriteLine("-> {0}\'s not pointy!", s[i].PetName);
					 
				// Can I draw you in 3D?
				if(s[i] is IDraw3D)
					DrawThisShapeIn3D((IDraw3D)s[i]);
				Console.WriteLine();
			}
			return 0;		
		}
	}
}
