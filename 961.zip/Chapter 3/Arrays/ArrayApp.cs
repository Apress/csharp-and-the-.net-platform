using System;

namespace Arrays
{
	class Arrays
	{
		public static void PrintArray(int[] myInts)
		{
			for(int i = 0; i < myInts.Length; i++)
				Console.WriteLine("Item {0} is {1}", i, myInts[i]);
		}

		public static string[] GetStringArray()
		{
			string[] theStrings = {"Hello", "from", "GetStringArray"};
			return theStrings;
		}

		public static int Main(string[] args)
		{
			#region Array declarations  
		
			// A string array containing 10 elements {0, 1, ...,9}.
			string[] booksOnCOM;	
			booksOnCOM = new string[10];		

			// A 2 item string array, numbered {0, 1}
			string[] booksOnPL1 = new string[2];	

			// 100 item string array, numbered {0, 1, ..., 99}
			string[] booksOnDotNet = new string[100];	

			// The size of this array will automatically be set to 4.  
			// Note the lack of the 'new' keyword.
			int[] ages = {20, 22, 23, 0};
	
			// Need 'new' keyword when you define a fixed size array.
			// Uncomment to trigger error.
			// int[4] ages = {30, 54, 4, 10};		// Error!  
			#endregion 

			Console.WriteLine("***** Array as Parameter *****");
			PrintArray(ages);

			Console.WriteLine("\n***** Array as return value *****");
			string[] strs = GetStringArray();
			foreach(string s in strs)
				Console.WriteLine(s);

			Console.WriteLine("\n***** A rectangular MD array *****\n");
			int[,] myMatrix;
			myMatrix = new int[6,6];

			// Populate (6 * 6) array.
			for(int i = 0; i < 6; i++)
				for(int j = 0; j < 6; j++)
					myMatrix[i, j] = i * j;

			// Show (6 * 6) array.
			for(int i = 0; i < 6; i++)
			{
				for(int j = 0; j < 6; j++)
				{				
					Console.Write(myMatrix[i, j] + "\t");
				}
				Console.WriteLine();
			}

			Console.WriteLine("\n***** A jagged MD array *****\n");   
			int[][] myJagArray = new int[5][];

			// Create the jagged array.
			for (int i = 0; i < myJagArray.Length; i++)
			{
				myJagArray[i] = new int[i + 7];
			}
 
			// Print each row (remember, each element is 
			// defaulted to zero!
			for(int i = 0; i < 5; i++)
			{
				Console.Write("Length of row {0} is {1}:\t", i, myJagArray[i].Length);
				for(int j = 0; j < myJagArray[i].Length; j++)
				{								
					Console.Write(myJagArray[i][j] + " ");
				}
				Console.WriteLine();
			}

			// Initialize items at startup or...
			Console.WriteLine("\n***** Created array of strings *****");
			string[] firstNames = 
				new string[5]{"Steve", "Gina", "Swallow", "Baldy", "Gunner"};

			// ...go member by member.
			/*
			string[] firstNames = new string[4];
			firstNames[0] = "Steve";
			firstNames[1] = "Gina";
			firstNames[2] = "Swallow";
			firstNames[3] = "Baldy";
			firstNames[4] = "Gunner";
			*/
		
			// Print out names in declared order.
			for(int i = 0; i < firstNames.Length; i++)
			{
				// Print a name
				Console.Write(firstNames[i] + "\t");
			}
		
			// Reverse them...
			Array.Reverse(firstNames);

			// ... and print them.
			Console.WriteLine("\n\n***** Here is the array once reversed *****");
			for(int i = 0; i < firstNames.Length; i++)
			{
				Console.Write(firstNames[i] + "\t");
			}
			Console.WriteLine("\n");

			// Clear out all but the final member.
			Console.WriteLine("***** Cleared out all but young Gunner *****");
			Array.Clear(firstNames, 1, 4);
			for(int i = 0; i < firstNames.Length; i++)
			{
				Console.Write(firstNames[i]);
			}
			Console.WriteLine();
		
			return 0;
		}
	}
}
