using System;
using System.Collections;

namespace Indexer
{
	public class CarApp
	{
		public static void Main()
		{
			Cars carLot = new Cars();
		
			// Add to car array.
			carLot[0] = new Car("FeeFee", 200, 0);
			carLot[1] = new Car("Clunker", 90, 0);
			carLot[2] = new Car("Zippy", 30, 0);

			// Now get and display each.
			Console.WriteLine("***** Using Cars indexer *****");
			for(int i = 0; i < carLot.GetNumberOfCars(); i++)
			{
				Console.WriteLine("Car number {0}:", i);
				Console.WriteLine("Name: {0}", carLot[i].PetName);
				Console.WriteLine("Max speed: {0}\n", carLot[i].MaxSpeed);
			}

			try
			{	// Iterate using IEnumerable.
				Console.WriteLine("***** Using IEnumerable *****");
				foreach (Car c in carLot)
				{
					Console.WriteLine("Name: {0}", c.PetName);
					Console.WriteLine("Max speed: {0}\n", c.MaxSpeed);
				}
			}
			catch{}			
		}
	}
}
