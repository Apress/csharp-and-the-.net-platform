using System;
using System.Threading;

namespace SimpleThreadApp
{
	class ThreadApp
	{
		#region helper f(x)
		static void MyThreadProc()
		{
			Console.WriteLine("***** Secondary Thread stats *****");
			Thread.CurrentThread.Name = "TheSecondaryThread";
			Thread secondaryThread = Thread.CurrentThread;
			Console.WriteLine("Name? {0}", secondaryThread.Name);
			Console.WriteLine("Apt state? {0}", secondaryThread.ApartmentState);
			Console.WriteLine("Alive? {0}", secondaryThread.IsAlive);
			Console.WriteLine("Priority? {0}", secondaryThread.Priority);			
			Console.WriteLine("State? {0}", secondaryThread.ThreadState);
			Console.WriteLine();

			for(int i = 0; i < 1000; i ++)
			{
				Console.WriteLine("Value of i is: {0}", i);
				Thread.Sleep(5);
			}
		}
		#endregion

		// [MTAThread]
		[STAThread]
		static void Main(string[] args)
		{
			// Get some info about the current thread.
			Thread primaryThread = Thread.CurrentThread;

			// Name the thread.
			primaryThread.Name = "ThePrimaryThread";

			// Get name of current AppDomain and context ID.
			Console.WriteLine("***** Primary Thread stats *****\n");
			Console.WriteLine("Name of current AppDomain: {0}", Thread.GetDomain().FriendlyName);
			Console.WriteLine("ID of current Context: {0}", Thread.CurrentContext.ContextID);

			Console.WriteLine("Thread Name: {0}", primaryThread.Name);
			Console.WriteLine("Apt state: {0}", primaryThread.ApartmentState);
			Console.WriteLine("Alive: {0}", primaryThread.IsAlive);
			Console.WriteLine("Priority Level: {0}", primaryThread.Priority);			
			Console.WriteLine("Thread State: {0}", primaryThread.ThreadState);
			Console.WriteLine();

			// Start a new worker thread.
			Thread secondaryThread = new Thread(new ThreadStart(MyThreadProc));
			secondaryThread.Priority = ThreadPriority.Highest;

			// Comment out the following line to test foreground / worker behaviors.
			secondaryThread.IsBackground = true;
			secondaryThread.Start();
		}
	}
}
