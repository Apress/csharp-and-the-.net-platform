using System;

namespace HelloWSClient
{
	class HelloClient
	{
		static void Main(string[] args)
		{
			// This proxy class makes use of 
			// a client side *.config file. 
			HelloClass c = new HelloClass();
			Console.WriteLine(c.HelloWorld());			
		}
	}
}
