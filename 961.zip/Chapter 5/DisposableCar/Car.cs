using System;

namespace DisposeMe
{
	// This car implements IDisposable
	// in order to allow the object
	// user to manually deallocate resources.
	public class Car : IDisposable
	{
		// Internal state data.
		private int currSpeed;
		private int maxSpeed;
		private string petName;

		public Car(){maxSpeed = 100;}

		public Car(string name, int max, int curr)
		{
			currSpeed = curr;
			maxSpeed = max;
			petName = name;
		}

		// IDisposable impl.
		public void Dispose()
		{
			// Clean up any managed resources.
			Console.WriteLine("In Dispose() for {0}!", petName);
		}
	}
}