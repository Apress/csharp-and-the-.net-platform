using System;
using System.Threading;
using System.Windows.Forms;

namespace SimpleMultiThreadApp
{
	#region Worker class type
	internal class WorkerClass
	{
		public void DoSomeWork()
		{
			// Get some information about the worker thread.
			Console.WriteLine("-> ID of worker thread is: {0}",
				Thread.CurrentThread.GetHashCode());	

			// Do the work.
			Console.Write("Worker says: ");
			for(int i = 0; i < 10; i++)
			{
				Console.WriteLine(i + ", ");
				Thread.Sleep(2000);
			}
			Console.WriteLine();
		}
	}
	#endregion 

	public class MainClass
	{
		public static int Main(string[] args)
		{
			Console.WriteLine("***** The Amazing Thread App *****\n");
			Console.Write("Do you want [1] or [2] threads? ");
			string threadCount = Console.ReadLine();

			// Name the current thread.
			Thread primaryThread = Thread.CurrentThread;	
			primaryThread.Name = "Boss Man";
			Console.WriteLine("-> ID of {0} is: {1}", 
				primaryThread.Name,
				primaryThread.GetHashCode());
			
			// Make worker class.
			WorkerClass w = new WorkerClass();

			#region Get user pref.
			switch(threadCount)  	
			{
				case  "2":
					// Now make the thread.
					Thread backgroundThread = 
						new Thread(new ThreadStart(w.DoSomeWork));
					backgroundThread.Start();
					break;

				case "1":		
					w.DoSomeWork();
					break;
				
				default:
					Console.WriteLine("I don't know what you want...you get 1 thread.");
					w.DoSomeWork();
					break;
			}
			#endregion

			// Do some additional work.
			MessageBox.Show("I'm buzy!", "Work on main thread...");            
			return 0;
		}
	}
}
