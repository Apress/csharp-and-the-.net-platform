using System;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;

namespace FillDSOleDbAdapter
{
	public class MyOleDbDataAdapter
	{
		#region print table helper f(x)
		public static void PrintTable(DataSet ds)
		{
			// Print out results from table.
			Console.WriteLine("Here is what we have right now:\n");
			DataTable invTable = ds.Tables["Inventory"];

			// Print the Column names.
			for(int curCol= 0; curCol< invTable.Columns.Count; curCol++)
			{
				Console.Write(invTable.Columns[curCol].ColumnName.Trim() + "\t");
			}
			Console.WriteLine();

			// Print each cell.
			for(int curRow = 0; curRow < invTable.Rows.Count; curRow++)
			{
				for(int curCol= 0; curCol< invTable.Columns.Count; curCol++)					
				{
					Console.Write(invTable.Rows[curRow][curCol].ToString().Trim()+ "\t");				
				}
				Console.WriteLine();
			}
			Console.WriteLine();
		}
		#endregion 

		public static int Main(string[] args)
		{
			Console.WriteLine("***** Inventory via Data Adapter *****");
			// The data set to be populated. 
			DataSet myDS = new DataSet("CarsDataSet");

			// Open a connection.			
			OleDbConnection cn = new OleDbConnection();
			cn.ConnectionString = "Provider=SQLOLEDB.1;server=(local);uid=sa;pwd=;database=Cars";
			cn.Open();

			// Create a SELECT command.
			OleDbCommand selectCmd = new OleDbCommand("SELECT * FROM Inventory", cn); 
	
			// Make a data adapter & associate commands.
			OleDbDataAdapter dAdapt = new OleDbDataAdapter();
			dAdapt.SelectCommand = selectCmd;

			// Establish table mappings. 
			DataTableMapping tblMapper = dAdapt.TableMappings.Add("Table", "Inventory");
			tblMapper.ColumnMappings.Add("CarID", "ID");
			tblMapper.ColumnMappings.Add("Make", "Brand");
			tblMapper.ColumnMappings.Add("PetName", "Friendly name of Car");

			// Create and fill the DataSet.
			try
			{
				dAdapt.Fill(myDS);
			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		
			PrintTable(myDS);
			return 0;
		}
	}
}
