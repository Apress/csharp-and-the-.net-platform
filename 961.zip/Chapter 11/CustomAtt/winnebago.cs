using System;
// Assembly level attributes don't have to 
// be in the assemblyinfo.cs file...but must
// be lised outside of any namespae definition. 
[assembly:System.CLSCompliantAttribute(true)]

namespace CustomAtt
{
	[VehicleDescription("A very long, slow but feature rich auto")]
    public class Winnebago
    {
        public Winnebago()
        {
        }

		// Uncomment to generate error...
		// public ulong notCompliant;
    }
}
