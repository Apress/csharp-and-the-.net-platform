using System;
using System.Windows.Forms;

namespace VsTestApp
{
	public class HelloClass
	{
		public HelloClass(){}
		public void SayHi()
		{
			MessageBox.Show("Hello from HelloClass�");
		}
	}
}
