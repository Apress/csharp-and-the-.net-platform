using System;

namespace Nested
{
	public class CarApp
	{
		public static int Main(string[] args)
		{		
			// Make a car.
			Console.WriteLine("***** Creating car and cranking tunes *****");
			Car c1;
			c1 = new Car("SlugBug", 100, 10);

			// Can�t do it! Uncomment to test.
			// Radio r = new Radio();

			// Jam some tunes.
			c1.CrankTunes(true);

			// Speed up.
			Console.WriteLine("\n***** Speeding up *****");
			for(int i = 0; i < 10; i++)
				c1.SpeedUp(20);

			// Shut down.
			Console.WriteLine("\n***** Turning off radio *****");
			c1.CrankTunes(false);
			return 0;
		}

	}
}
