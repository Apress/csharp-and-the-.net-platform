#pragma once
#include "stdafx.h"

#using <mscorlib.dll>

// Uncommnet these lines if you are not using VS .NET 2003,
// as older version of VS .NET did not have the Add Ref
// dialog!
//#using "C:\VbCarClient.exe"
//#using "C:\CarLibrary.dll"
#using <System.Windows.Forms.dll>

using namespace VBCarClient;
using namespace System;

// A MC++ class deriving from a VB .NET class
// (which derives from a C# class!)
__gc class JamesBondCar :
	public PerformanceCar
{
public:
	JamesBondCar(void){} 
	~JamesBondCar(void){}
	virtual void TurboBoost()
	{
		Console::WriteLine("Diving, flying and drilling...");
		PerformanceCar::TurboBoost();
	}
};

// This is the entry point for this application
#ifdef _UNICODE
int wmain(void)
#else
int main(void)
#endif
{
	// Make a JamesBondCar.
	Console::WriteLine(S"Making a JamesBondCar!");
	JamesBondCar* jbc = new JamesBondCar();
	jbc->PetName = S"Jello";
	jbc->TurboBoost();
	Console::Write("Car is called: ");
	Console::WriteLine(jbc->PetName);
	Console::Write("JBC's base class is: ");
	Console::WriteLine(jbc->GetType()->BaseType->ToString());
    return 0;
}