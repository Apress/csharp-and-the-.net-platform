using System;

// Needed for CultureInfo type.
using System.Globalization;

namespace TypeConversions
{
	class TypeCodeTester
	{
		static void Main(string[] args)
		{			
			// Get the type code of C# int.
			int theInt = 65;
			Console.WriteLine("***** TypeCode System.Int32 *****");
			Console.WriteLine("Type code of int is: {0}", 
				theInt.GetTypeCode());

			// Now, convert theInt to 
			// System.Char using standard cast.
			Console.WriteLine("\n***** Casting System.Int32 to System.Char *****");
			char theChar = (char)theInt;  
			Console.WriteLine("Type code int converted to char is: {0}", 
				theChar.GetTypeCode());
			Console.WriteLine("Value of converted char: {0}", theChar);
			
			// Now get IConvertible from the System.Int32.
			Console.WriteLine("\n***** IConvertible-ing System.Int32 to System.Byte *****");
			IConvertible itfConvert = (IConvertible)theInt;
			byte theByte = itfConvert.ToByte(CultureInfo.CurrentCulture);
			Console.WriteLine("Type code int converted to byte is: {0}", 
				theByte.GetTypeCode());
			Console.WriteLine("Value of converted int: {0}", theByte);

			// Convert a System.String into a System.Boolean using System.Convert.
			string theString = "true";
			Console.WriteLine("\n***** Convert.ToBoolean(theString) *****");			  
			bool theBool = Convert.ToBoolean(theString);
			Console.WriteLine("Type code string converted to bool is: {0}", 
				theBool.GetTypeCode());
			Console.WriteLine("Value of converted string: {0}", theBool);
		}
	}
}
