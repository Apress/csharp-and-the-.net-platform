using System;
using System.Reflection;

namespace TheType
{
	public class FooReader
	{
		#region Static helper methods

		public static void GetNestEnumStats()
		{
			Console.WriteLine("***** Nested Enum Info *****");
			Type t = Type.GetType("TheType.Foo+MyNestedEnum");
			Console.WriteLine("Enum name? {0}", t.Name);
			Console.WriteLine("Is enum nested private? {0}", t.IsNestedPrivate);
			Console.WriteLine("Is enum nested public? {0}", t.IsNestedPublic);
			Console.WriteLine("***********************************\n");
		}

		public static void MapInterfaceMethodsToClassMethods(Foo f)
		{
			Console.WriteLine("***** Explicit interface impl mappings *****");
			Type t = f.GetType();
			
			// Get all interfaces on type.
			Type[] iFaces = t.GetInterfaces();

			// Do the following for each interface on type.
			for(int i = 0; i < iFaces.Length; i ++)
			{
				Console.WriteLine("Info on Interface named: {0}", iFaces[i]);

				// Get method infos for name of method on the class. 
				MethodInfo[] classMethodNames = t.GetInterfaceMap(iFaces[i]).TargetMethods;
				MethodInfo[] interfaceMethodNames = t.GetInterfaceMap(iFaces[i]).InterfaceMethods;

				for(int j = 0; j < classMethodNames.Length; j++)
				{
					Console.WriteLine("Interface method: {0}",  
						interfaceMethodNames[j].Name);
					Console.WriteLine("is implemented by class method: {0}", 
						classMethodNames[j].Name);
				}
				Console.WriteLine();
			}
			Console.WriteLine("***********************************\n");
		}

		public static void ListVariousStats(Foo f)
		{
			Console.WriteLine("***** Various stats about Foo *****");
			Type t = f.GetType();
			Console.WriteLine("Full name is: {0}", t.FullName);
			Console.WriteLine("Base is: {0}", t.BaseType);
			Console.WriteLine("Is it abstract? {0}", t.IsAbstract);
			Console.WriteLine("Is it a COM object? {0}", t.IsCOMObject);
			Console.WriteLine("Is it sealed? {0}", t.IsSealed);
			Console.WriteLine("Is it a class? {0}", t.IsClass);
			Console.WriteLine("***********************************\n");
		}

		public static void ListMethods(Foo f)
		{
			Console.WriteLine("***** Methods of Foo *****");
			Type t = f.GetType();
			MethodInfo[] mi = t.GetMethods();
			foreach(MethodInfo m in mi)
				Console.WriteLine("Method: {0}", m.Name);
			Console.WriteLine("*************************\n");
		}

		public static void ListFields(Foo f)
		{
			Console.WriteLine("***** Fields of Foo *****");
			Type t = f.GetType();
			FieldInfo[] fi = t.GetFields();
			foreach(FieldInfo field in fi)
				Console.WriteLine("Field: {0}", field.Name);
			Console.WriteLine("*************************\n");
		}

		public static void ListProps(Foo f)
		{
			Console.WriteLine("***** Properties of Foo *****");
			Type t = f.GetType();
			PropertyInfo[] pi = t.GetProperties();
			foreach(PropertyInfo prop in pi)
				Console.WriteLine("Prop: {0}",  prop.Name);
			Console.WriteLine("*****************************\n");
		}

		public static void ListInterfaces(Foo f)
		{
			Console.WriteLine("***** Interfaces of Foo *****");
			Type t = f.GetType();
			Type[] ifaces = t.GetInterfaces();
			foreach(Type i in ifaces)
				Console.WriteLine("Interface: {0}", i.Name);
			Console.WriteLine("*****************************\n");	
		}
		#endregion

		public static int Main(string[] args)
		{
			// Make a Foo type.
			Foo theFoo = new Foo();

			// Now examine everything.
			ListVariousStats(theFoo);
			ListMethods(theFoo);
			ListFields(theFoo);
			ListProps(theFoo);
			ListInterfaces(theFoo);
			GetNestEnumStats();
			MapInterfaceMethodsToClassMethods(theFoo);
			return 0;
		}
	}
}
