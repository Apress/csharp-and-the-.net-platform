using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace CarControlLibrary
{
	#region Helper enumeration
	// enum for images.
	public enum AnimFrames
	{
		Lemon1,
		Lemon2,
		Lemon3,
		AlmostDead,
		Dead
	}
	#endregion 

	// Mark the default event and property for this control.
	[ToolboxBitmap(typeof(CarControl), "CarControl")]
	[DefaultEvent("BlewUp"), DefaultProperty("Anim")] 
	public class CarControl : System.Windows.Forms.UserControl
	{
		#region State data
		// State data.
		private System.ComponentModel.IContainer components;
		private AnimFrames currFrames = AnimFrames.Lemon1;
		private AnimFrames currMaxFrames = AnimFrames.Lemon3;
		private bool IsAnim;
		private int currSp = 50;
		private System.Windows.Forms.PictureBox pictureBox;
		private int maxSp = 100;
		private System.Windows.Forms.Timer animTimer ;
		private string carPetName= "NoName";
		private Rectangle bottomRect = new Rectangle();
		private System.Windows.Forms.ImageList theImageList; 
		private Color txtPaneColor;
		#endregion 

		// Car events / custom delegate.
		public delegate void CarEventHandler(string msg);

		[Category("Car Configuration"), 
		Description("Sent when the car is approaching terminal speed.")] 
		public event CarEventHandler AboutToBlow;

		[Category("Car Configuration"), 
		Description("Sent when the car bites the big one.")] 
		public event CarEventHandler BlewUp;

		public CarControl()
		{
			//This call is required by the Windows Form Designer.
			InitializeComponent();

			// set color.
			txtPaneColor = Color.Indigo;

			// Prep the box.
			StretchBox();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}
	
		#region Windows Form Designer generated code  
		//Required by the Windows Form Designer

		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.  
		//Do not modify it using the code editor.
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CarControl));
			this.animTimer = new System.Windows.Forms.Timer(this.components);
			this.theImageList = new System.Windows.Forms.ImageList(this.components);
			this.pictureBox = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// animTimer
			// 
			this.animTimer.Interval = 200;
			this.animTimer.Tick += new System.EventHandler(this.animTimer_Tick);
			// 
			// theImageList
			// 
			this.theImageList.ImageSize = new System.Drawing.Size(47, 47);
			this.theImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("theImageList.ImageStream")));
			this.theImageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// pictureBox
			// 
			this.pictureBox.Location = new System.Drawing.Point(24, 40);
			this.pictureBox.Name = "pictureBox";
			this.pictureBox.Size = new System.Drawing.Size(102, 52);
			this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox.TabIndex = 0;
			this.pictureBox.TabStop = false;
			// 
			// CarControl
			// 
			this.Controls.Add(this.pictureBox);
			this.Name = "CarControl";
			this.Resize += new System.EventHandler(this.CarControl_Resize);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.CarControl_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		#region Properties...
		// Controls current speed.
		[Category("Car Configuration"), 
		Description("Configure speed of auto"), 
		DefaultValue(50)] 
		public int Speed 
		{
			get{return currSp;}	    
			set
			{
				currSp = value;
				currFrames = currMaxFrames;
				// About to explode?
				if ((maxSp - currSp) <= 10) 
				{
					AboutToBlow("Slow down dude!");
					currMaxFrames = AnimFrames.AlmostDead;
				}
				// Maxed out?
				if (currSp >= maxSp) 
				{
					currSp = maxSp;
					BlewUp("Ug...you're toast...");
					currMaxFrames = AnimFrames.Dead;
				}
			}
		}

		// Controls the windows timer.
		[Category("Car Configuration"), 
		Description("Do you want to animate?"), 
		DefaultValue(false)] 
		public bool Anim
		{
			get {return IsAnim;}
			set
			{
				IsAnim = value;
				animTimer.Enabled = IsAnim;
			}
		}

		// Configure the pet name.
		[Category("Car Configuration"), 
		Description("Pet name for your auto."), 
		DefaultValue("No Name")] 
		public string PetName
		{
			get{return carPetName;}
			set
			{
				carPetName = value;
				Invalidate();
			}
		}

		// Configure color of text pane.
		[Category("Car Configuration"), 
		Description("set color of text area")] 
		public Color TextPaneColor
		{ 
			get{return txtPaneColor;}
			set
			{
				txtPaneColor = value;
				Invalidate();
			}
		}
		#endregion 

		private void StretchBox()
		{
			// Configure picture box.
			pictureBox.Top = 0;
			pictureBox.Left = 0;
			pictureBox.Height = this.Height - 50;
			pictureBox.Width = this.Width;
			pictureBox.Image = theImageList.Images[(int)AnimFrames.Lemon1];

			// Figure out size of bottom rect.
			bottomRect.X = 0;
			bottomRect.Y = this.Height - 50;
			bottomRect.Height = this.Height - pictureBox.Height;
			bottomRect.Width = this.Width;
		}

		private void animTimer_Tick(object sender, System.EventArgs e)
		{
			if(IsAnim) 
			{
				// Here we are loading from the ImageList
				// thus, these items are embedded into the 
				// assembly.
				pictureBox.Image = theImageList.Images[(int)currFrames];
			}

			// Bump frame.
			string s = Enum.Format(typeof(AnimFrames), currFrames, "D");
			int i = int.Parse(s);
			int nextFrame = i + 1;
			currFrames = (AnimFrames)nextFrame;

			if (currFrames > currMaxFrames) 
				currFrames = AnimFrames.Lemon1;    		
		}

		private void CarControl_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			// Render the petname on the bottom of the control.
			Graphics g = e.Graphics;
			g.DrawString(PetName, new Font("Times New Roman", 15), 
				Brushes.Black, bottomRect);		
		}

		private void CarControl_Resize(object sender, System.EventArgs e)
		{
			StretchBox();
			Invalidate();		
		}
	}
}