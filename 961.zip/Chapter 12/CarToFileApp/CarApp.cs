using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;	// Binary format.
using System.Runtime.Serialization.Formatters.Soap;		// SOAP format.
using System.Xml.Serialization;							// XML format.
	
namespace CarToFileApp
{
	public class CarApp
	{
		public static void Main()
		{
			// Make a car and listen to the tunes.
			Console.WriteLine("***** Creating a new James Bond Car *****");
			JamesBondCar myAuto = new JamesBondCar("Fred", 50, false, true);
			myAuto.TurnOnRadio(true);
			myAuto.GoUnderWater();

			#region Use binary formatter
			// Now save this car to a binary stream.
			Console.WriteLine("\n***** Saving your type to CarData.dat *****");
			FileStream myStream = File.Create("CarData.dat");
			BinaryFormatter myBinaryFormat = new BinaryFormatter();
			myBinaryFormat.Serialize(myStream, myAuto);
			myStream.Close();
			Console.WriteLine("Done!");

			// Read in the Car from the binary stream.
			Console.WriteLine("\n***** Reading car from binary file *****");
			myStream = File.OpenRead("CarData.dat");
			JamesBondCar carFromDisk = (JamesBondCar)myBinaryFormat.Deserialize(myStream);
			Console.WriteLine("{0} is alive!", carFromDisk.PetName);
			carFromDisk.TurnOnRadio(true);
			myStream.Close();
			#endregion 

			#region Use SOAP formatter
			// Save the same car into SOAP format.
			Console.WriteLine("\n***** Saving car to CarSoapData.xml file *****");
			myStream = File.Create("CarSoapData.xml");
			SoapFormatter mySoapFormat = new SoapFormatter();
			mySoapFormat.Serialize(myStream, myAuto);
			myStream.Close();
			Console.WriteLine("Done!");

			// Read in the Car from the SOAP file.
			Console.WriteLine("\n***** Reading car from soap file *****");
			myStream = File.OpenRead("CarSoapData.xml");
			JamesBondCar carFromSoap = (JamesBondCar)mySoapFormat.Deserialize(myStream);
			Console.WriteLine("{0} is alive!", carFromSoap.PetName);
			carFromSoap.TurnOnRadio(true);
			myStream.Close();
			#endregion

			#region Use XML formatter
			// Now save car using a pure XML format.
			Console.WriteLine("\n***** Saving car to CarXmlData.xml file *****");
			myStream = File.Create("CarXmlData.xml");
			XmlSerializer myXmlFormat = new XmlSerializer(typeof(JamesBondCar), "Cars");
			myXmlFormat.Serialize(myStream, myAuto);
			myStream.Close();

			// Read in the Car from the XML file.
			Console.WriteLine("\n***** Reading car from Xml file *****");
			myStream = File.OpenRead("CarXmlData.xml");
			JamesBondCar carFromXml = (JamesBondCar)myXmlFormat.Deserialize(myStream);
			Console.WriteLine("{0} is alive!", carFromXml.PetName);
			carFromSoap.TurnOnRadio(true);
			myStream.Close();
			#endregion 
		}
	}
}
