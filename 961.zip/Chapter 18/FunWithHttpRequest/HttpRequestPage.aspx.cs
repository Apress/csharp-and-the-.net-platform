using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace FunWithHttpRequest
{
	public class HttpRequestPage : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button btnGetBrowserStats;
		protected System.Web.UI.WebControls.Button btnGetRequestStats;
		protected System.Web.UI.WebControls.Label lblOutput;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			lblOutput.Visible = false;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGetBrowserStats.Click += new System.EventHandler(this.btnGetBrowserStats_Click);
			this.btnGetRequestStats.Click += new System.EventHandler(this.btnGetRequestStats_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnGetBrowserStats_Click(object sender, System.EventArgs e)
		{
			lblOutput.Visible = true;
			string theInfo = "";
			theInfo += String.Format("<li>Is the client AOL? {0}", 
				Request.Browser.AOL);
			theInfo += 
				String.Format("<li>Does the client support ActiveX? {0}", 
				Request.Browser.ActiveXControls);
			theInfo += String.Format("<li>Is the client a Beta? {0}", 
				Request.Browser.Beta);
			theInfo += 
				String.Format("<li>Dose the client support Applets? {0}", 
				Request.Browser.JavaApplets);
			theInfo += 
				String.Format("<li>Does the client support Cookies? {0}", 
				Request.Browser.Cookies);
			theInfo += 
				String.Format("<li>Does the client support VBScript? {0}", 
				Request.Browser.VBScript);
			lblOutput.Text = theInfo;
		}

		private void btnGetRequestStats_Click(object sender, System.EventArgs e)
		{
			lblOutput.Visible = true;
			string theInfo = "";
			theInfo += String.Format("<li>Path of Virtual directory? {0}", 
				Request.ApplicationPath);
			theInfo += String.Format("<li>Byte length of request? {0}", 
				Request.ContentLength);
			theInfo += String.Format("<li>Virtual path? {0}", 
				Request.FilePath);
			theInfo += String.Format("<li>Http method? {0}", 
				Request.HttpMethod);
			theInfo += String.Format("<li>Raw URL? {0}", Request.RawUrl);
			theInfo += String.Format("<li>IP address? {0}", 
				Request.UserHostAddress);
			theInfo += String.Format("<li>DNS name? {0}", 
				Request.UserHostName);
			lblOutput.Text = theInfo;	
	
			// Now save all stats to file.
			Request.SaveAs(@"C:\temp\requestDump.txt", true);
		}
	}
}
