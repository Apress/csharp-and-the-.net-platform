using System;

namespace Employees
{
	public sealed class PTSalesPerson : SalesPerson
	{
		public PTSalesPerson(string fullName, int empID, 
			float currPay, string ssn, int numbOfSales) 
				: base(fullName, empID, currPay, ssn, numbOfSales){}
	}

	#region Uncomment to test...
	// Uncomment to test sealed base class...
	/*
	public class ReallyPTSalesPerson : PTSalesPerson
	{
		public ReallyPTSalesPerson()
		{
		}
	}
	*/
	#endregion
}
