using System;

namespace IFaceHierarchy
{
	public class TheApp
	{
		public static int Main(string[] args)
		{
			Console.WriteLine("***** Working with SuperImage *****");
			SuperImage si = new SuperImage();
		
			// Get IDraw.
			IDraw itfDraw = (IDraw)si;
			itfDraw.Draw();
		
			// Now get IDraw3.
			if(itfDraw is IDraw3)
			{
				IDraw3 itfDraw3 = (IDraw3)itfDraw;
				itfDraw3.DrawToMetaFile();
				itfDraw3.DrawToPrinter();
			}

			Console.WriteLine("\n***** Working with JBCar *****");
			JBCar j = new JBCar();
			if(j is IJamesBondCar)
			{			
				((IJamesBondCar)j).Drive();
				((IJamesBondCar)j).TurboBoost();
				((IJamesBondCar)j).Dive();
			}

			return 0;
		}
	}
}
