using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace SimpleMdiApp
{
	/// <summary>
	/// Summary description for KidPrototypeForm.
	/// </summary>
	public class KidPrototypeForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public KidPrototypeForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// KidPrototypeForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 269);
			this.Name = "KidPrototypeForm";
			this.Text = "KidPrototypeForm";
			this.Click += new System.EventHandler(this.KidPrototypeForm_Click);

		}
		#endregion

		private void KidPrototypeForm_Click(object sender, System.EventArgs e)
		{
			// Get three random numbers
			int r, g, b;
			Random ran = new Random();
			r = ran.Next(0, 255);
			g = ran.Next(0, 255);
			b = ran.Next(0, 255);
			Color currColor = Color.FromArgb(r, g, b);
			this.BackColor = currColor;
			this.Text = currColor.ToString();		
		}
	}
}
