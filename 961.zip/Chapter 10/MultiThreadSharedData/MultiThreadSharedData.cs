using System;
using System.Threading;

namespace MultiThreadSharedData
{
	#region Worker class
	internal class WorkerClass
	{
		private int theInt;

		public void DoSomeWork()
		{
			lock(this)
			{
				theInt++;
				// Do the work.
				for(int i = 0; i < 5; i++)
				{
					Console.WriteLine("theInt: {0}, i: {1}, current thread: {2}",
						theInt, i, Thread.CurrentThread.Name);
					Thread.Sleep(1000);
				}
			}
		}
	}
	#endregion 

	public class MainClass
	{
		public static int Main(string[] args)
		{
			// Make the worker object.
			WorkerClass w = new WorkerClass();

			// Create three secondard threads,
			// each of which makes calls to the same 
			// shared object.
			Thread workerThreadA = new Thread(new ThreadStart(w.DoSomeWork));
			workerThreadA.Name = "A";
			Thread workerThreadB = new Thread(new ThreadStart(w.DoSomeWork));
			workerThreadB.Name = "B";
			Thread workerThreadC = new Thread(new ThreadStart(w.DoSomeWork));
			workerThreadC.Name = "C";

			// Now start each one.
			workerThreadA.Start();
			workerThreadB.Start();
			workerThreadC.Start();
			
			return 0;
		}
	}
}
