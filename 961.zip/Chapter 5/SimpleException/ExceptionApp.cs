using System;
namespace SimpleException
{
	public class ExceptionApp
	{
		public static int Main(string[] args)
		{
			// Make a simple car.
			Console.WriteLine("***** Creating a car and stepping on it *****");
			Car buddha = new Car("Buddha", 100, 20);
			buddha.CrankTunes(true);

			// Try to rev the engine hard!
			try
			{
				for(int i = 0; i < 10; i++)
				{
					buddha.SpeedUp(10);
				}
			}
			catch(Exception e)
			{
				Console.WriteLine("\n*** Error! ***");
				Console.WriteLine("Class defining member: {0}", 
					e.TargetSite.DeclaringType);
				Console.WriteLine("Member type: {0}", e.TargetSite.MemberType);
				Console.WriteLine("Member name: {0}", e.TargetSite);
				Console.WriteLine("Message: {0}", e.Message);
				Console.WriteLine("Source: {0}", e.Source);
				Console.WriteLine("Stack: {0}", e.StackTrace);
				Console.WriteLine("Help Link: {0}", e.HelpLink);
 			}

			Console.WriteLine("\n***** Out of exception logic *****");			
			return 0;
		}
	}
}
