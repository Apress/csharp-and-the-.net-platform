using System;

namespace MethodsAndParams
{
	#region Person helper class
	// Simple class to demo params keyword.
	class Person
	{
		public string fullName;
		public int age;

		public Person(string n, int a)
		{
			fullName = n;
			age = a;
		}

		public void PrintInfo()
		{
			Console.WriteLine("{0} is {1} years old", fullName, age);
		}
	}
	#endregion 

	class Methods
	{
		#region Static helper methods. 
		// Looks a lot like [in] and [out], does it not?
		public static void Add(int x,int y, out int ans)
		{
			ans = x + y;
		}

		// Same as...
		public static int Add(int x, int y)
		{
			return x + y;
		}

		// Returning multiple output parameters.
		public static void FillTheseValues(out int a, out string b, out bool c)
		{
			a = 9;
			b = "Enjoy your string...";
			c = true;
		}

		// reference parameter.
		public static void UpperCaseThisString(ref string s)
		{
			s = s.ToUpper();
		}

		// params keyword.
		public static void ArrayOfInts(string msg, params int[] list) 
		{
			Console.WriteLine(msg);

			for ( int i = 0 ; i < list.Length ; i++ )
				Console.WriteLine(list[i]);
			Console.WriteLine();
		}

		public static void ArrayOfObjects(params object[] list) 
		{
			for ( int i = 0 ; i < list.Length ; i++ )
			{	 
				if(list[i] is Person)
				{
					((Person)list[i]).PrintInfo();
				}
				else
					Console.WriteLine(list[i]);
			}
			Console.WriteLine();
		}

		public static void SendAPersonByValue(Person p)
		{
			// Change some data of 'p'.
			p.age = 666;

			// This will be forgotten after the call!
			p = new Person("Nikki", 999);
		}

		public static void SendAPersonByReference(ref Person p)
		{
			// Change some data of 'p'.
			p.age = 555;

			// 'p' is now reassigned!
			p = new Person("Nikki", 999);
		}
		#endregion 

		public static void Main() 
		{
			Console.WriteLine("***** Fun with Params *****");
			// Use 'out' keyword (no need to assign because it is an out).
			Console.WriteLine("Adding 2 ints using out keyword");
			int ans;
			Add(90, 90, out ans);
			Console.WriteLine("90 + 90 = {0}\n", ans);

			// Method with multiple output params.
			Console.WriteLine("***** Calling method with multiple output params *****");
			int i;
			string str;
			bool b;
			FillTheseValues(out i, out str, out b);
			Console.WriteLine("Int is: {0}", i);
			Console.WriteLine("String is: {0}", str);
			Console.WriteLine("Boolean is: {0}\n", b);

			// Use 'ref'
			Console.WriteLine("***** Changing string using ref keyword *****");
			string s = "Can you really have sonic hearing for $19.00?";
			Console.WriteLine("-> Before: {0}", s);
			UpperCaseThisString(ref s);
			Console.WriteLine("-> After: {0}\n", s);

			// Use 'params' keyword.
			Person p = new Person("Fred", 93);
			Console.WriteLine("***** Sending in args using params keyword *****");
			ArrayOfObjects(777, p, "I really am an instance of System.String"); 

			int[] intArray = new int[3] {10,11,12};
			ArrayOfInts("Here is an array of ints", intArray);
			ArrayOfInts("Enjoy these 3 ints", 1, 2, 3);
			ArrayOfInts("Take some more!", 55, 4, 983, 10432, 98, 33);

			// Passing ref-types by value and by ref.
			Console.WriteLine("***** Passing person by value *****");
			Person fred = new Person("Fred", 12);
			Console.WriteLine("Before by value call, Person is:");
			fred.PrintInfo();
			SendAPersonByValue(fred);
			Console.WriteLine("After by value call, Person is:");
			fred.PrintInfo();
		
			// Passing ref-types by ref.
			Console.WriteLine("\n***** Passing person by reference *****");
			Person mel = new Person("Mel", 23);
			Console.WriteLine("Before by value call, Person is:");
			mel.PrintInfo();
			Console.WriteLine("After by ref call, Person is:");
			SendAPersonByReference(ref mel);
			Console.WriteLine("After by value call, Person is:");
			mel.PrintInfo();
		}
	}
}