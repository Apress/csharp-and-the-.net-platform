using System;
using System.Windows.Forms;

namespace CarToFileApp
{
	[Serializable]
	public class Radio
	{
		// This field is only for example purposes!
		// The point is that if you have a 
		// point of data you do not wish to 
		// serialize, apply the [NonSerialized]
		// attribute.
		[NonSerialized]
		private int objectIDNumber = 9;

		public Radio(){}
		public void On(bool state)
		{
			if(state == true)
				MessageBox.Show("Music is on...");
			else
				MessageBox.Show("No tunes...");				
		}
	}
}
