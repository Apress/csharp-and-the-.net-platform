using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Drawing2D;

namespace BasicPaintForm
{
	/// <summary>
	///		Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		/// <summary>
		///		Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button btnRenderedButton;
		private System.Windows.Forms.Button btnRenderToOtherButton;
		private ArrayList myPts = new ArrayList();

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			CenterToScreen();
			this.Text = "Basic Paint Form (click on me)";

		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		#region Windows Form Designer generated code
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnRenderedButton = new System.Windows.Forms.Button();
			this.btnRenderToOtherButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnRenderedButton
			// 
			this.btnRenderedButton.Location = new System.Drawing.Point(168, 120);
			this.btnRenderedButton.Name = "btnRenderedButton";
			this.btnRenderedButton.Size = new System.Drawing.Size(112, 136);
			this.btnRenderedButton.TabIndex = 0;
			this.btnRenderedButton.Text = "Click on other button!";
			this.btnRenderedButton.Click += new System.EventHandler(this.btnRenderedButton_Click);
			// 
			// btnRenderToOtherButton
			// 
			this.btnRenderToOtherButton.Location = new System.Drawing.Point(168, 8);
			this.btnRenderToOtherButton.Name = "btnRenderToOtherButton";
			this.btnRenderToOtherButton.Size = new System.Drawing.Size(112, 56);
			this.btnRenderToOtherButton.TabIndex = 1;
			this.btnRenderToOtherButton.Text = "Render to button";
			this.btnRenderToOtherButton.Click += new System.EventHandler(this.btnRenderToOtherButton_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.btnRenderToOtherButton);
			this.Controls.Add(this.btnRenderedButton);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Basic Paint Form";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.MainForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// 	The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void MainForm_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			// Add to points collection.
			myPts.Add(new Point(e.X, e.Y));
			Invalidate();
		}

		private void MainForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			g.DrawString("Hello GDI+", new Font("Times New Roman", 20), 
				new SolidBrush(Color.Black), 0, 0);

			foreach(Point p in myPts)
				g.DrawEllipse(new Pen(Color.Green), p.X, p.Y, 10, 10);
		}

		private void btnRenderedButton_Click(object sender, System.EventArgs e)
		{
			string msg = "Image is erased when you click me becuase\n";
			msg += "the graphical data was rendered on the other button\'s\n";
			msg += "click event."; 
			MessageBox.Show(msg);
		}

		private void btnRenderToOtherButton_Click(object sender, System.EventArgs e)
		{
			// Get graphics object for Button on Form.
			Graphics buttonGraphics = 
				Graphics.FromHwnd(btnRenderedButton.Handle);
			
			// Make an interesting brush.
			// (must use System.Drawing.Drawing2D namespace to get HatchBrush!)
			HatchBrush b = new HatchBrush(HatchStyle.Cross, 
				Color.Purple, Color.Gold);
			
			// Render onto the button
			buttonGraphics.FillRectangle(b,
					0, 0, 50, btnRenderedButton.Height);
		}
	}
}
