using System;

namespace CalcWSClient
{
	class TheClient
	{
		public static MyWayCoolWebCalculator ws = new MyWayCoolWebCalculator();

		static void Main(string[] args)
		{
			// Exercise the proxy!
			Console.WriteLine("***** The amazing Web Service Client App *****\n");	
			Console.WriteLine("2 + 3 = {0}", ws.Add(2, 3));
			Console.WriteLine("23.4 + 33.1 = {0}", ws.Add(23.4F, 33.1F));
			Console.WriteLine("My random number is: {0}", ws.GetMyRandomNumber());
			Console.WriteLine("Simple value of PI is: {0}", ws.GetSimplePI());
			Console.WriteLine();

			// Now aynch. invocation.
			Console.WriteLine("Calling Add() asynchronously");
			AsyncCallback cb = new AsyncCallback(AdditionDone);
			IAsyncResult result = ws.BeginAdd(30, 21, cb , null);
			Console.ReadLine();

			#region polling via IsCompleted
			// Just to simulate work on the client.
//			for(int i = 0; i < 50; i++) 
//			{
//				Console.WriteLine("Primary thread working...");
//				if(result.IsCompleted)
//				{
//					Console.WriteLine("30 + 32 = {0}", ws.EndAdd(result));
//					break;
//				}
//			}
			#endregion
		}
		
		// Target for delegate. 
		public static void AdditionDone(IAsyncResult result)
		{
			Console.WriteLine("30 + 32 = {0}", ws.EndAdd(result));
		}
	}
}
