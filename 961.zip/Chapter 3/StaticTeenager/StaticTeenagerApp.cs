using System;

namespace StaticTeenager
{

	class Teenager
	{
		static private Random r = new Random();
		
		// Private function used to grab a random number.
		private static int GetRandomNumber(short upperLimit)
		{
			// Return a random message.
			return r.Next(upperLimit);
		}

		// Two public methods for the teenager class
		// which both make use of a private helper function.
		public static string Complain()
		{
			string[] messages = new string[5]{"Do I have to?",
												 "He started it!",
												 "I'm too tired...",
												 "I hate school!",
												 "You are sooo wrong."};
			return messages[GetRandomNumber(5)];
		}

		public static string BeAgreeable()
		{
			string[] messages = new string[3]{"Sure!  No problem!",
												 "Uh uh.",
												 "I guess so."};
			return messages[GetRandomNumber(3)];
		}



		public static void Main(string[] args)
		{
			// Let mike do his thing.
			Console.WriteLine("***** Mike says *****");
			for(int i = 0; i < 10; i++)
			{
				Console.WriteLine("-> {0}", Teenager.Complain());
			}
			// Now be agreeable.
			Console.WriteLine("-> {0}", Teenager.BeAgreeable());
		}
	}
}
