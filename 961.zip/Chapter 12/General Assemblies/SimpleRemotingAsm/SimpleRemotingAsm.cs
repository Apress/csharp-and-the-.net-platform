using System;

namespace SimpleRemotingAsm
{
	// This is a simple type that can be 
	// remoted by reference (MBR).
	public class RemoteMessageObject: MarshalByRefObject
	{
		// The ctor prints a message just to
		// confirm it has been activated.
		public RemoteMessageObject()
		{
			Console.WriteLine("RemoteMessageObject ctor called!");
		}

		// This method takes an input string 
		// from the caller.
		public void DisplayMessage(string msg)
		{
			Console.WriteLine("Message is: {0}", msg);
		}

		// This method returns a value to the
		// caller.
		public string ReturnMessage()
		{
			return "Hello from the server!";
		}
	}
}
