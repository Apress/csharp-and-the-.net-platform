using System;

namespace StaticReadOnlyData
{
	#region helper classes
	// The Tire class has a number of readonly fields. 
	public class Tire
	{ 
		// Given that the state of the Tire type is determined at
		// runtime, we cannot use the �const� keyword here!
		// ERROR: public const Tire GoodStone = new Tire(90);

		// In contrast, the �readonly� keyword can be assigned
		// values which are computed at runtime.
		public static readonly Tire GoodStone = new Tire(90);
		public static readonly Tire FireYear = new Tire(100);
		public static readonly Tire ReadyLyne= new Tire(43);
		public static readonly Tire Blimpy = new Tire(83);

		private int manufactureID;

		public int MakeID
		{ get {  return manufactureID; } } 

		public Tire (int ID) 
		{ manufactureID = ID; } 
	} 

 	// Make use of a dynamically created readonly field. 
	public class Car
	{ 
		// What sort of tires do I have?
		public Tire tireType = Tire.Blimpy;  // Returns a new Tire.
	} 
	#endregion 

	public class CarApp
	{ 
		public static int Main(string[] args)
		{ 
			Car c = new Car();
			Console.WriteLine("***** Manufacture ID of tires: {0} *****", 
				c.tireType.MakeID);
			return 0;
		} 
	}
}
