/** 
 ** NOTE!  +checked as been enabled !
 **/

using System;

namespace CheckedUnchecked
{
	class TheChecker
	{
		static void Main(string[] args)
		{
			// Overflow the max value of a System.Byte.
			Console.WriteLine("***** System.Byte stats *****");
			Console.WriteLine("Max value of byte is {0}.", byte.MaxValue);
			Console.WriteLine("Min value of byte is {0}.", byte.MinValue);

			// Underflow conditions trigger an OverflowException!
			Console.WriteLine("\n***** Catching an underflow *****");
			try
			{
				byte a = 9, b = 9;
				byte c = (byte)(a + b + -100);
			}
			catch(OverflowException e){Console.WriteLine(e);}

			Console.WriteLine("\n***** Working with unchecked code *****");
			byte b1 = 100;
			byte b2 = 250;
			try
			{
				// Assuming +checked is enabled,
				// this block will not trigger
				// a runtime exception.
				unchecked
				{
					byte b3 = (byte)(b1 + b2);
					byte b4, b5 = 100, b6 = 200;
					b4 = (byte)(b5 + b6);
					Console.WriteLine("b3 = {0}", b3);
					Console.WriteLine("b4 = {0}", b4);			 
				}
			}
			catch(OverflowException e)
			{ 
				Console.WriteLine(e.Message);
			}		
		}
	}
}
