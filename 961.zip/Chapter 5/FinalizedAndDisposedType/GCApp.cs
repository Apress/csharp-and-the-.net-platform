using System;

namespace GCTest
{
	public class GCApp
	{
		public static int Main(string[] args)
		{		
			// Add these cars to the managed heap.
			Console.WriteLine("***** Adding cars to heap *****");
			Car c1, c2, c3, c4;

			c1 = new Car("Car one", 40, 10);
			c2 = new Car("Car two", 70, 5);
			c3 = new Car("Car three", 200, 100);
			c4 = new Car("Car four", 140, 80);
			
			// manually dispose some.
			Console.WriteLine("\n***** Disposing c1 and c3 *****");
			c1.Dispose();
			c3.Dispose();
			
			return 0;
		}
	}
}

