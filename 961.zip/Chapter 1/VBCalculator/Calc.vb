' Note!  VB .NET does also 
' support a Namespace keyword,
' however every VB .NET project
' created with VS .NET gets a
' free 'root' namespace which is 
' the name of the project. 

' The VB calc...
Class Calc
    Public Function Add(ByVal x As Integer, _
    ByVal y As Integer) As Integer
        Return x + y
    End Function
End Class

' A VB .NET 'module' is a class
' defining only static members.
Module CalcApp
    Sub Main()
        Dim ans As Integer
        Dim c As New Calc()
        ans = c.Add(10, 84)
        Console.WriteLine("10 + 84 is: {0}.", ans)
    End Sub
End Module
