using System;
using System.Reflection;
using System.IO;

namespace CarReflector
{
	public class CarReflector
	{
		#region Helper methods 
		// Here are the methods to check out all types.
		private static void ListAllTypes(Assembly a)
		{
			Console.WriteLine("***** Types in Assembly *****");
			Console.WriteLine("->{0}\n", a.FullName);
			Type[] types = a.GetTypes();
			foreach(Type t in types)
				Console.WriteLine("Type: {0}", t);
			Console.WriteLine("******************************\n");
		}

		private static void ListAllMembers(Assembly a)
		{
			Console.WriteLine("***** Members of MiniVan *****");
			Type miniVan = a.GetType("CarLibrary.MiniVan");
			MemberInfo[] mi = miniVan.GetMembers();
			foreach(MemberInfo m in mi)
				Console.WriteLine("{0}: {1} ",
					m.MemberType.ToString(), m);
			Console.WriteLine("******************************\n");
		}

		private static void GetParams(Assembly a)
		{
			Console.WriteLine("***** Here are the params for TurnOnRadio() *****");
			Type miniVan = a.GetType("CarLibrary.MiniVan");
			MethodInfo mi = miniVan.GetMethod("TurnOnRadio");	
			// Show number of params.
			ParameterInfo[] myParams = mi.GetParameters();		
			Console.WriteLine("Method has {0} params", myParams.Length);
		
			// Show info about param.
			foreach(ParameterInfo pi in myParams)
			{
				Console.WriteLine("Param name: {0}", pi.Name);
				Console.WriteLine("Position in method: {0}", pi.Position);				
				Console.WriteLine("Param type: {0}", pi.ParameterType);
			}
			Console.WriteLine("******************************\n");
		}
		#endregion 

		// This application dynamically loads 
		// an assembly and investigates the types.
		public static int Main(string[] args)
		{
			// Use Assembly class to load the CarLibrary.
			Assembly a = null;
			try
			{
				// You can use a string...
				// a = Assembly.Load(@"CarLibrary, Version=1.0.982.23972, PublicKeyToken=null, Culture=""");

				// ...or AssemblyName reference...
				AssemblyName asmName;
				asmName = new AssemblyName();
				asmName.Name = "CarLibrary";
				Version v = new Version("1.0.982.23972");
				asmName.Version = v;

				// ...to load an assembly!
				a = Assembly.Load(asmName);

			}
			catch(FileNotFoundException e)
			{Console.WriteLine(e.Message);}

			// Check everything out.
			ListAllTypes(a);
			ListAllMembers(a);
			GetParams(a);
			return 0;
		}
	}
}
