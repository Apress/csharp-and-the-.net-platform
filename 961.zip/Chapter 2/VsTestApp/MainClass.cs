using System;
using System.Windows.Forms;

namespace VsTestApp
{
	class MainClass
	{
		[STAThread]
		static void Main(string[] args)
		{
			Console.WriteLine("Hello again!");
			// Make a HelloClass type.
			HelloClass h = new HelloClass();
			h.SayHi();
		}
	}
}
