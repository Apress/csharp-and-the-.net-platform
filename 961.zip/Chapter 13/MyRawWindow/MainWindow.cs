using System;
using System.Windows.Forms;

namespace MyRawWindow
{	
    public class MainWindow : Form
    {
        public MainWindow(){}
    }

	public class TheApp
	{
		// Run this application.
		public static int Main(string[] args) 
		{
			Application.Run(new MainWindow());
			return 0;
		}
	}
}
