using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CustomSerialization
{
	public class App
	{
		public static int Main(string[] args)
		{
			// Make a car and listen to the tunes.
			Console.WriteLine("***** Making Car *****");
			CustomCarType myAuto = new CustomCarType("Sid", 50);
			
			// Create a file stream.	
			Stream myStream = File.Create("CarData.dat");
			
			// Move our graph into the stream using a binary format.
			Console.WriteLine("\n***** Saving Car to file *****");
			BinaryFormatter myBinaryFormat = new BinaryFormatter();
			myBinaryFormat.Serialize(myStream, myAuto);
			myStream.Close();

			Console.WriteLine("\n***** Reading Car from file *****");
			myStream = File.OpenRead("CarData.dat");
			CustomCarType carFromDisk = 
				(CustomCarType)myBinaryFormat.Deserialize(myStream);
			Console.WriteLine("{0} is alive!\n", carFromDisk.petName);
			myStream.Close();
			return 0;
		}
	}
}
