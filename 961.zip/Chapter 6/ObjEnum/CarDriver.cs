using System;
using System.Collections;

namespace ObjEnum
{

	// No pun intended!
	public class CarDriver
	{
		public static void Main()
		{
			Cars carLot = new Cars();

			Console.WriteLine("***** Here are the cars in your lot *****");
			foreach (Car c in carLot)
			{
				Console.WriteLine("-> Name: {0}", c.PetName);
				Console.WriteLine("-> Max speed: {0}", c.MaxSpeed);
				Console.WriteLine();
			}

			#region Working with raw IEnumerator
			/*
			// Now ala IEnumerator
			IEnumerator itfEnum;
			itfEnum = (IEnumerator)carLot;

			// Reset the cursor to the beginning.
			itfEnum.Reset();

			// Advance internal cursor by 1.
			itfEnum.MoveNext();
		
			// Cast to a Car and crank some tunes.
			object curCar = itfEnum.Current;
			((Car)curCar).CrankTunes(true);
			*/
			#endregion 
		}
	}
}
