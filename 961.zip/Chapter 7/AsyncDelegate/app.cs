using System;
using System.Threading;

namespace AsyncDelegate
{
	// The delegate. 
	public delegate string NewCarDelegate(Car carToDetail);

	public class Car{}

	class App
	{
		public static string DetailCar(Car c)
		{
			// detail car for 10 seconds. 
			Console.WriteLine("Detailing car on thread {0}", 
				Thread.CurrentThread.GetHashCode());
			Thread.Sleep(10000);
			return "Your car is ready!";
		}

		static void Main(string[] args)
		{
			Console.WriteLine("***** Asynch Delegate Take 1 *****");
			Console.WriteLine("Main() is on thread {0}", 
				Thread.CurrentThread.GetHashCode());

			NewCarDelegate d = new NewCarDelegate(DetailCar);
			Car myCar = new Car();

			// Call synchronously
			// Console.WriteLine(d(myCar));

			// Call asynchronously.
			IAsyncResult itfAR = d.BeginInvoke(myCar, null, null);
						
			Console.WriteLine("Done invoking delegate");
			
			// Get answer from delegate. 
			string msg = d.EndInvoke(itfAR);
			Console.WriteLine(msg);
		}
	}
}
