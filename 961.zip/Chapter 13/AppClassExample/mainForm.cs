using System;
using System.Windows.Forms;

namespace AppClassExample
{
	public class mainForm : System.Windows.Forms.Form
	{
		private MyMessageFilter msgFliter = new MyMessageFilter();

		public mainForm()
		{
			// Get some properties of this app.
			GetStats();

			// Add a delegate to grab Exit event.
			Application.ApplicationExit += new EventHandler(Form_OnExit);

			// Add a message filter.
			Application.AddMessageFilter(msgFliter);		
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new mainForm());
		}

		private void GetStats()
		{
			// Read some metadata from the manifest.
			string info = string.Format("Company: {0}\n", 
				Application.CompanyName);
			info += string.Format("App Name: {0}\n", 
				Application.ProductName);
			info += string.Format("I live here: {0}", 
				Application.StartupPath);
			MessageBox.Show(info);
		}

		// Event handlers.
		private void Form_OnExit(object sender, EventArgs evArgs) 
		{
			MessageBox.Show("See ya!", "This app is dead...");
			Application.RemoveMessageFilter(msgFliter);
		}
	}

	#region The message fliter 
	// Create a  message filter.
	public class MyMessageFilter : IMessageFilter 
	{
		public bool PreFilterMessage(ref Message m) 
		{
			// Intercept the left mouse button down message.
			if (m.Msg == 513) 
			{
				MessageBox.Show("WM_LBUTTONDOWN is: " + m.Msg);
				return true;
			}
			return false;
		}
	}
	#endregion 
}
