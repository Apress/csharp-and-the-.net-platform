Imports UserConvLib

Module UserConvApp

    Sub Main()
        Console.WriteLine("***** VB .NET client calling conversions via special name *****")
        ' Implicit cast OK!
        Dim s As Square
        s.sideLength = 83
        Dim rect As Rectangle = Rectangle.op_Implicit(s)
        Console.WriteLine("rect2 = {0}", rect)

        ' Explicit cast syntax still OK!
        Dim s2 As Square
        s2.sideLength = 3
        Dim rect2 As Rectangle = Rectangle.op_Implicit(s2)
        Console.WriteLine("rect3 = {0}", rect2)
    End Sub

End Module
