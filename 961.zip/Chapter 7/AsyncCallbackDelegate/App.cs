using System;
using System.Threading;
using System.Runtime.Remoting.Messaging;

namespace AsyncCallbackDelegate
{
	// The delegate. 
	public delegate string NewCarDelegate(Car carToDetail);

	public class Car{}

	class App
	{
		public static void DetailCarCallBack(IAsyncResult itfAR)
		{
			Console.WriteLine("DetailCarCallBack on thread {0}", 
				Thread.CurrentThread.GetHashCode());			
			
			// Get message from DetailCar().
			AsyncResult res = (AsyncResult)itfAR;
			NewCarDelegate d = (NewCarDelegate)res.AsyncDelegate;
			Console.WriteLine(d.EndInvoke(itfAR));			
		}

		public static string DetailCar(Car c)
		{
			// detail car for 10 seconds. 
			Console.WriteLine("Detailing car on thread {0}", 
				Thread.CurrentThread.GetHashCode());
			Thread.Sleep(10000);
			return "Your car is ready!";
		}

		static void Main(string[] args)
		{
			Console.WriteLine("Main() is on thread {0}", 
				Thread.CurrentThread.GetHashCode());

			NewCarDelegate d = new NewCarDelegate(DetailCar);
			Car myCar = new Car();

			// Call synchronously
			// Console.WriteLine(d(myCar));

			// Call asynchronously.
			IAsyncResult itfAR = d.BeginInvoke(myCar, new AsyncCallback(DetailCarCallBack), null);
						
			Console.WriteLine("Done invoking delegate");
			
			// Get answer from delegate. 
			// string msg = d.EndInvoke(itfAR);
			Console.ReadLine();
		}
	}
}

