using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SessionState
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox txtCarMake;
		protected System.Web.UI.WebControls.TextBox txtCarColor;
		protected System.Web.UI.WebControls.TextBox txtDownPayment;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.CheckBox chkIsLeasing;
		protected System.Web.UI.WebControls.Calendar myCalendar;
		protected System.Web.UI.WebControls.Button btnSubmit;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Label lblUserInfo;
		protected System.Web.UI.WebControls.Label lblUserID;
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				lblUserInfo.Visible = false;
				lblUserID.Visible = false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnSubmit_Click(object sender, System.EventArgs e)
		{
			lblUserInfo.Visible = true;
			lblUserID.Visible = true;

			// Set current user prefs.
			UserShoppingCart u = 
				(UserShoppingCart)Session["UserShoppingCartInfo"];
			u.dateOfPickUp = myCalendar.SelectedDate;
			u.desiredCar = txtCarMake.Text;
			u.desiredCarColor = txtCarColor.Text;
			u.downPayment = float.Parse(txtDownPayment.Text);
			u.isLeasing = chkIsLeasing.Checked;
			lblUserInfo.Text = u.ToString();
			lblUserID.Text = string.Format("Here is your ID: {0}",
				Session.SessionID);
			Session["UserShoppingCartInfo"] = u;			
		}
	}
}
