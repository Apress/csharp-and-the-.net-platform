Imports System.Windows.Forms
Imports CommonSnappableTypes

<SnappableAttribute()> Public Class VbNetSnapIn
    Implements IUseMyFunctionality

    Public Sub DoIt() Implements IUseMyFunctionality.DoIt
        MessageBox.Show("You have just used the VB .NET snap in!")
    End Sub
End Class
