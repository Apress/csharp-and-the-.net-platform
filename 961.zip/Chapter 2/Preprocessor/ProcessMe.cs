// This symbole is already
// defined at the project 
// level, however for 
// illustrative purposes...
#define DEBUG

// Uncomment to disable the 
// project wide FOO symbol.
// #undef FOO

using System;
namespace Preprocessor
{
	class ProcessMe
	{
		[STAThread]
		static void Main(string[] args)
		{
			Console.WriteLine("***** The Preprocessor App *****\n");
			// Are we in debug mode?
			// If so, issue a compiler warning.
			#if (DEBUG)
			#warning Beware!  Debug is defined...
			Console.WriteLine("App directory: {0}", 
				Environment.CurrentDirectory);
			Console.WriteLine("Box: {0}", 
				Environment.MachineName);
			Console.WriteLine("OS: {0}", 
				Environment.OSVersion);
			Console.WriteLine(".NET Version: {0}", 
				Environment.Version);
			#endif			

			// This custom symbol is defined
			// at the project level.
			#if (FOO)
			Console.WriteLine("FOO symbol is enabled!");
			#endif
		}

		// #line allows you to alter the 
		// natural line positioning used
		// by the compiler.  Setting #line
		// back to 'default' resumes the 
		// normal flow. 
#line 3000
#warning "Changed to line 3000 (for no good reason)...
		#region Stuff I Don�t Care About
		public class MyHelperClass
		{ // stuff�
		}
		public interface MyHelperInterface
		{// stuff�
		}
		#endregion
#line default
	}
}








