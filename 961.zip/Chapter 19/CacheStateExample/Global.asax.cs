using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;

// Need these!
using System.Web.Caching;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace CacheState 
{
	public class Global : System.Web.HttpApplication
	{
		private System.ComponentModel.IContainer components = null;
		
		// Define a static level Cache object. 
		private static Cache theCache;

		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{
			// First assign the static 'theCache' variable.
			theCache = Context.Cache;

			// When the application starts up,
			// read the current values in the
			// Inventory table. 
			SqlConnection cn = 
				new SqlConnection("data source=localhost;initial catalog=Cars; user id ='sa';pwd=''");
			SqlDataAdapter dAdapt = new SqlDataAdapter("Select * From Inventory", cn);
			DataSet theCars = new DataSet();
			dAdapt.Fill(theCars, "Inventory");

			// Now store in the cache.
			theCache.Insert("AppDataSet",
				theCars, null, 
				DateTime.Now.AddSeconds(15), 
				Cache.NoSlidingExpiration, 
				CacheItemPriority.Default, 
				new CacheItemRemovedCallback(UpdateCarInventory));
		}
 
		// The handler for the cache item remove delegate.
		static void UpdateCarInventory(string key, object item, CacheItemRemovedReason reason)
		{
			// Populate the DataSet.
			SqlConnection cn = 
				new SqlConnection("data source=localhost;initial catalog=Cars; user id ='sa';pwd=''");
			SqlDataAdapter dAdapt = new SqlDataAdapter("Select * From Inventory", cn);
			DataSet theCars = new DataSet();
			dAdapt.Fill(theCars, "Inventory");

			// Now store in the cache.
			theCache.Insert("AppDataSet",
				theCars, null, 
				DateTime.Now.AddSeconds(15), 
				Cache.NoSlidingExpiration, 
				CacheItemPriority.Default, 
				new CacheItemRemovedCallback(UpdateCarInventory));
		}

		#region Event handlers we don't care about.
		protected void Session_Start(Object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_Error(Object sender, EventArgs e)
		{

		}

		protected void Session_End(Object sender, EventArgs e)
		{

		}

		protected void Application_End(Object sender, EventArgs e)
		{

		}
		#endregion 

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
		}
		#endregion
	}
}

