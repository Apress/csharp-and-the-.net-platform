using System;

namespace CarDataTable
{
    public class Car
    {
		// Make public for easy access...
		public string petName, make, color;

        public Car(string petName, string make, string color)
        {
			this.petName = petName;
			this.color = color;
			this.make = make;
        }
    }
}
