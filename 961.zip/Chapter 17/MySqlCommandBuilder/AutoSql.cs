using System;
using System.Data;
using System.Data.SqlClient;

namespace MySqlCommandBuilder
{
	class AutoSqlMe
	{
		#region Print table helper f(x)
		public static void PrintTable(DataSet ds)
		{
			// Print out results from table.
			Console.WriteLine("Here is what we have right now:\n");
			DataTable invTable = ds.Tables["Inventory"];

			// Print the Column names.
			for(int curCol= 0; curCol< invTable.Columns.Count; curCol++)
			{
				Console.Write(invTable.Columns[curCol].ColumnName.Trim() + "\t");
			}
			Console.WriteLine();

			// Print each cell.
			for(int curRow = 0; curRow < invTable.Rows.Count; curRow++)
			{
				for(int curCol= 0; curCol< invTable.Columns.Count; curCol++)					
				{
					Console.Write(invTable.Rows[curRow][curCol].ToString().Trim()+ "\t");				
				}
				Console.WriteLine();
			}
			Console.WriteLine();
		}
		#endregion

		static void Main(string[] args)
		{
			Console.WriteLine("***** The Command Builder App *****\n");
			DataSet theCarsInventory = new DataSet();

			// Make connection.
			SqlConnection cn = new 
				SqlConnection("server=(local);User ID=sa;Pwd=;database=Cars");
			
			// Autogenerate INSERT, UPDATE and DELETE commands.
			SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Inventory", cn);
			SqlCommandBuilder invBuilder = new SqlCommandBuilder(da);

			// Print out values of the generated command objects.
			Console.WriteLine("SELECT command: {0}", da.SelectCommand.CommandText);
			Console.WriteLine("\nUPDATE command: {0}", invBuilder.GetUpdateCommand().CommandText);
			Console.WriteLine("\nINSERT command: {0}", invBuilder.GetInsertCommand().CommandText);
			Console.WriteLine("\nDELETE command: {0}\n", invBuilder.GetDeleteCommand().CommandText);

			// Fill dataset.
			da.Fill(theCarsInventory, "Inventory");
			PrintTable(theCarsInventory);

			// Delete a row and update database.
			try
			{      
				theCarsInventory.Tables["Inventory"].Rows[6].Delete();
				da.Update(theCarsInventory, "Inventory");   
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);
			}

			// Refill and reprint Inventory table.
			theCarsInventory = new DataSet("CarsDataSet");
			da.Fill(theCarsInventory, "Inventory");
			PrintTable(theCarsInventory);
		}
	}
}
