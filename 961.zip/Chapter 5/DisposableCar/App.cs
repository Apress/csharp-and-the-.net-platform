using System;

namespace DisposeMe
{
	// Helper type.
	public class NotDisposible{}

	public class GCApp
	{
		public static int Main(string[] args)
		{
			// Uncomment to trigger compile time error.
			// using(NotDisposible x = new NotDisposible()){}

			using(Car c = new Car("Used car", 40, 10))
			{
				// Use the car.
				// Dispose() is called automatically when the
				// using block exits.
			}

			// Add cars to the managed heap.
			Car c1 = new Car("Car one", 40, 10);

			// Manually call Dispose().
			c1.Dispose();			
			return 0;

		} // c and c1 'may' be cleaned up here...
	}
}

