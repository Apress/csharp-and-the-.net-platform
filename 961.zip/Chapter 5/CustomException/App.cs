using System;

namespace Exceptions
{
	public class App
	{
		public static void Main()
		{
			// Make a car.
			Console.WriteLine("***** Creating car and speeding up *****");
			Car buddha = new Car("Buddha", 100, 20);

			// Try to rev the engine hard!
			try
			{
				// Uncomment to trigger arg out of range ex.
				// buddha.SpeedUp(-10);

				for(int i = 0; i < 10; i++)
				{
					buddha.SpeedUp(10);
				}
			}
			catch(CarIsDeadException e)
			{ 
				Console.WriteLine("\n*** Error! ***");
				Console.WriteLine("Method: {0}", e.TargetSite);
				Console.WriteLine("Message: {0}", e.Message);
				Console.WriteLine("=> Stack trace: {0}", e.StackTrace);
			} 
			catch(ArgumentOutOfRangeException e)
			{ 
				Console.WriteLine("\n*** Error! ***");
				Console.WriteLine("Method: {0}", e.TargetSite);
				Console.WriteLine("Message: {0}", e.Message);
				Console.WriteLine("=> Stack trace: {0}", e.StackTrace);
			}
			catch(Exception e)
			{
				Console.WriteLine("\n*** Error! ***");
				Console.WriteLine("Method: {0}", e.TargetSite);
				Console.WriteLine("Message: {0}", e.Message);
				Console.WriteLine("=> Stack trace: {0}", e.StackTrace);
			}
			finally
			{ 
				// This will always occur. Exception or not.
				buddha.CrankTunes(false);
			} 
		}
	}
}
