using System;
using CommonSnappableTypes;
using System.Windows.Forms;

namespace CSharpSnapIn
{
	[Snappable]
	public class TheCSharpSnapIn : IUseMyFunctionality 
	{
		public TheCSharpSnapIn(){}
		void IUseMyFunctionality.DoIt()
		{
			MessageBox.Show("You have just used the C# snap in!");
		}
	}
}
