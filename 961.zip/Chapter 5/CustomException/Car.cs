using System;

namespace Exceptions
{
	#region car is dead exception type
	// Custom application exception.
	public class CarIsDeadException : System.ApplicationException
	{
		// Constructors for this exception.
		public CarIsDeadException(){}

		public CarIsDeadException(string message)
			: base(message){}

		public CarIsDeadException(string message, Exception innerEx)
			: base(message, innerEx){}
	}
	#endregion

	#region The Car Class
	public class Car 
	{
		// Internal state data.
		private int currSpeed;
		private int maxSpeed;
		private string petName;

		// Is the car alive or dead?
		bool carIsDead;

		// A car has-a radio.
		private Radio theMusicBox = new Radio();

		public Car()
		{
			maxSpeed = 100;
			carIsDead = false;
		}

		public Car(string name, int max, int curr)
		{
			currSpeed = curr;
			maxSpeed = max;
			petName = name;
			carIsDead = false;
		}

		public void CrankTunes(bool state)
		{
			// Tell the radio play (or not).
			// Delegate request to inner object.
			theMusicBox.TurnOn(state);
		}

		public void SpeedUp(int delta) 
		{
			// Bad param?
			if(delta < 0)
				throw new ArgumentOutOfRangeException("delta", "Speed must be greater than zero");

			// If the car is dead, just say so...
			if(carIsDead)
			{
				// Throw 'Car is dead' exception.
					throw new Exception("This car is already dead...");

				// throw new CarIsDeadException(this.petName + " has bought the farm!");
			}
			else	// Not dead, speed up.
			{
				currSpeed += delta;
				if(currSpeed >= maxSpeed)
				{
					carIsDead = true;
				}
				else
					Console.WriteLine("=> CurrSpeed = {0}", currSpeed);
			}
		}
	}
	#endregion 
}

