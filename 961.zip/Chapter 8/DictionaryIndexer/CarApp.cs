using System;
using System.Collections;

namespace DictionaryIndexer
{
	public class CarApp
	{
		public static void Main()
		{
			Cars carLot = new Cars();
			
			// Add to car array.
			carLot["FeeFee"] = new Car("FeeFee", 200, 0);
			carLot["Clunker"] = new Car("Clunker", 90, 0);
			carLot["Zippy"] = new Car("Zippy", 30, 0);

			// Now get Zippy.
			Console.WriteLine("***** Getting Zippy using indexer *****");
			Car zippy = carLot["Zippy"];
			Console.WriteLine("{0}'s max speed is {1} MPH",
				zippy.PetName, zippy.MaxSpeed);
		}
	}
}
