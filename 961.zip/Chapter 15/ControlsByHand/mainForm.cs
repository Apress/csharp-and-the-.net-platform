using System;	
using System.Drawing;
using System.Windows.Forms;

namespace ControlByHand
{
    class MyForm : Form
	{
		// Form widget member variables.
		private TextBox firstNameBox = new TextBox(); 
		private Button btnShowControls = new Button();
		
		public MyForm()
		{
			this.Text = "Controls in the raw";

			// Add a new text box.
			firstNameBox.Text = "Chucky";
			firstNameBox.Size = new Size(150, 50);
			firstNameBox.Location = new Point(10, 10);
			this.Controls.Add(firstNameBox);

			// Add a new button.
			btnShowControls.Text = "Examine Controls collection";
			btnShowControls.Size = new Size(90, 90);
			btnShowControls.Location = new Point(10, 70);
			btnShowControls.Click += 
				new EventHandler(btnShowControls_Clicked);
			this.Controls.Add(btnShowControls);

			CenterToScreen();
		}

		protected void btnShowControls_Clicked(object sender, EventArgs e)
		{
			// Iterate over each item in the 
			// controls collection and print
			// out stats.
			Control.ControlCollection coll = this.Controls;
			string ctrs = "";
			foreach(Control c in coll)
			{
				if(c != null)
					ctrs += string.Format("Index: {0}, Text: {1}\n", 
						coll.GetChildIndex(c, false), c.Text);			 	
			}
			MessageBox.Show(ctrs, "Index and Text values for each control");
		}

        public static int Main(string[] args)
        {
			Application.Run(new MyForm());
			return 0;
        }
    }
}
