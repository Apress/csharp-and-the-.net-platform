using System;
using System.IO;	// For file reading.

namespace Iterations
{
	class AgainAndAgain
	{
		public static int Main(string[] args)
		{
			// Your basic for loop.  
			Console.WriteLine("***** Your basic for loop *****");
			for(int i = 0; i < 10; i++)
			{
				Console.WriteLine("Number is: {0}", i);
			}
		
			// Uncomment to generate error.
			// Console.WriteLine(i);

			// Digging into an array using foreach
			// Using foreach with arrays
			string[] arrBookTitles = new string[] {"Complex algorithms", 
					"COM for the fearful programmer",
					"Do you remember classic COM?",
					"C# and the .NET Platform",
					"COM for the lonely engineer"};
			int COM = 0, NET = 0;

			Console.WriteLine("\n***** foreach iteration *****");
			foreach (string s in arrBookTitles) 
			{
				if (-1 != s.IndexOf("COM"))  
					COM++;      
				else if(-1 != s.IndexOf(".NET"))
					NET++;         
			}
			Console.WriteLine("Found {0} COM references and {1} .NET references.",
				COM, NET) ;
		
			// While loop.
			Console.WriteLine("\n***** while iteration *****");
			Console.WriteLine("=> Here is the contents boot.ini");		
			try
			{
				StreamReader sr = 
					File.OpenText("c:\\boot.ini");
				string strLine;
				while(null != (strLine = sr.ReadLine()))
				{
					Console.WriteLine(strLine);
				}
				sr.Close();
			}
			catch(FileNotFoundException e)
			{
				Console.WriteLine(e.Message);
			}

			// Do / while loop.
			Console.WriteLine("\n***** do/while iteration *****");
			string ans;
			do
			{
				Console.Write("Are you done? [yes] [no] : ");
				ans = Console.ReadLine();
			}while(ans != "yes");
			return 0;
		}
	}
}
