using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DynamicCtrls
{
	public class PanelPage : System.Web.UI.Page
	{
		#region member vars...
		protected System.Web.UI.WebControls.Panel thePanel;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label lblControlInfo;
		protected System.Web.UI.WebControls.Button btnAddTextBoxes;
		protected System.Web.UI.WebControls.Button btnRemoveAllItems;
		protected System.Web.UI.WebControls.Label lblTextBoxText;
		protected System.Web.UI.WebControls.Button btnGetTextBoxValues;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Show the controls on a panel. 
			ListControlsOnPanel();
		}

		public void ListControlsOnPanel()
		{
			lblControlInfo.Visible = true;

			string theInfo;
			theInfo = String.Format("Has controls? {0}<br>", 
				thePanel.HasControls());

			ControlCollection myCtrls = thePanel.Controls;
			foreach(Control c in myCtrls)
			{
				if(c.GetType() != typeof(System.Web.UI.LiteralControl))
				{
					theInfo += "***************************<br>";
					theInfo += String.Format("Control Name? {0}<br>", c.ToString());
					theInfo += String.Format("ID? {0}<br>", c.ID);
					theInfo += String.Format("Control Visible? {0}<br>", c.Visible);
					theInfo += String.Format("ViewState? {0}<br>", c.EnableViewState);
				}
			}
			lblControlInfo.Text = theInfo;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGetTextBoxValues.Click += new System.EventHandler(this.btnGetTextBoxValues_Click);
			this.btnRemoveAllItems.Click += new System.EventHandler(this.btnRemoveAllItems_Click);
			this.btnAddTextBoxes.Click += new System.EventHandler(this.btnAddTextBoxes_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnAddTextBoxes_Click(object sender, System.EventArgs e)
		{
			for(int i = 0; i < 5; i++)
			{
				// Assign a name so we can get 
				// the text value out later
				// using the HttpRequest.QueryString()
				// method.
				TextBox t = new TextBox();
				t.ID = string.Format("newTextBox{0}", i);
				thePanel.Controls.Add(t);
			}
			ListControlsOnPanel();
		}

		private void btnRemoveAllItems_Click(object sender, System.EventArgs e)
		{
			thePanel.Controls.Clear();
			ListControlsOnPanel();
		}

		private void btnGetTextBoxValues_Click(object sender, System.EventArgs e)
		{
			// To save GUI screen space.
			lblControlInfo.Visible = false;

			// Just incase the panel is empty
			string textBoxValues = "";
			for(int i = 0; i < Request.Form.Count; i++)
			{
				textBoxValues += 
					string.Format("<li>{0}</li><br>",
					Request.Form[i]);
			}
			lblTextBoxText.Text = textBoxValues;		
		}
	}
}
