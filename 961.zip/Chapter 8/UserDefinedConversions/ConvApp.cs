using System;

namespace UserDefinedConversions
{
	class ConvApp
	{
		// Helper function. 
		private static void DrawThisRect(Rectangle r)
		{
			r.Draw();
		}

		static void Main(string[] args)
		{
			Console.WriteLine("***** Converting Square to Rectangle *****");
			
			// Create a 10 * 10 square.
			Square sq;
			sq.sideLength = 3;
			Console.WriteLine("sq = {0}", sq);

			// Explicitly convert Square to a new Rectangle.
			Rectangle rect = (Rectangle)sq;
			Console.WriteLine("rect = {0}", rect);
	
			Console.WriteLine("\n***** Passing a Square into function *****");
			Console.WriteLine("********* requiring a Rectangle **********");
			DrawThisRect((Rectangle)sq);

			// Converting System.Int32 to Square.
			Console.WriteLine("\n***** Converting int to Square *****");
			Square sq2 = (Square)90;
			Console.WriteLine("sq2 = {0}", sq2);

			// Convert a Square to an System.Int32.
			Console.WriteLine("\n***** Converting Square to int *****");
			int side = (int)sq2;
			Console.WriteLine("Side of sq2 = {0}", side);

			// Attempt to make an implicit cast.
			Console.WriteLine("\n***** Implicitly converting Square to Rectangle *****");
			Square s3;
			s3.sideLength= 83;
			Rectangle rect2 = s3;
			Console.WriteLine("rect2 = {0}", rect2);
			DrawThisRect(s3);

			// Explicit cast syntax still OK!
			Console.WriteLine("\n***** () operator still OK! *****");
			Square s4;
			s4.sideLength = 3;
			Rectangle rect3 = (Rectangle)s4;
			Console.WriteLine("rect3 = {0}", rect3);
		}
	}
}
